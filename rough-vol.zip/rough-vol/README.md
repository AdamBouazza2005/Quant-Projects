# Is volatility rough, or is roughness a measurement artifact?

Gatheral, Jaisson and Rosenbaum estimate the Hurst exponent of log-volatility
at roughly 0.1. That estimate is computed from *realized* variance, which is
itself a noisy estimate of spot variance. Cont and Das, and Rogers, argue the
low exponent may be an artifact of that estimation error rather than a property
of volatility.

This project does not take a side by assertion. It builds the forward pipeline
-- known H, simulated price, realistic contamination, measured H-hat -- and maps
where the estimator is informative and where it is not.

---

## Headline result (20 independent replications per cell, bootstrap CIs)

All numbers from `python scripts/run_grid.py --reps 20` (seed 20260921),
saved in `results/grid_collapse.json` and `results/grid_decomp_noise.json`.

**1. The measured exponent collapses onto one variable.** The ratio of genuine
vol-of-vol signal to realized-variance sampling error in daily log-RV,

```
SNR  =  2 * nu  /  sqrt(2 / n_obs)
```

With **H_true = 0.50 in every run** -- a process with no roughness at all:

| quantity | estimate | 95% CI |
|---|---|---|
| rank correlation, SNR vs H-hat (24 cells) | 0.930 | 0.916 - 0.942 |
| mean H-hat, SNR < 1 (12 cells) | **0.128** | 0.124 - 0.131 |
| mean H-hat, SNR > 4 (5 cells) | 0.436 | 0.419 - 0.452 |
| SNR at which H-hat falls to half the truth | 0.86 | 0.82 - 0.90 |
| SNR needed for H-hat within 0.1 of truth | **3.2** | 2.7 - 4.2 |

At nu = 0.05 with 12 intraday observations, a Brownian volatility process
returns **H-hat = 0.094 +/- 0.014** -- the canonical "rough" figure.

**2. In the low-SNR regime the estimator is precise and wrong.** The
single-dataset standard deviation of H-hat there is only 0.019. So one dataset
rejects the *true* H = 0.5 in every cell below SNR 1, at z from 4.3 (cells just
under SNR 1) to 117 (the lowest-SNR cell); below SNR 0.5 every cell exceeds z = 11. The
estimator's own uncertainty gives no warning. A narrow confidence interval on a
published H-hat is therefore not evidence of roughness unless the SNR is also
reported.

**3. It is not specific to H = 0.5.** The same collapse holds at H_true = 0.3
(rank correlation 0.950; low-SNR H-hat 0.054) and H_true = 0.1 (0.925; 0.012).
Low SNR drives every process toward H-hat = 0.

**Where the collapse is imperfect -- and why.** The SNR variable accounts only
for sampling error sqrt(2/n), not microstructure noise. Cells sampled at the
finest grid (k = 1), where noise dominates RV, fall *below* the curve: at
nu = 0.01, SNR = 0.54 predicts H-hat around 0.2 but the cell reads 0.064. An
effective SNR including noise variance is the obvious extension. Also, even at
high SNR H-hat plateaus near 0.40-0.46 rather than 0.50, so a residual bias
remains in the best regime tested.

**Two kinds of uncertainty, reported separately.** `sd` is the dispersion
across replications: what one researcher with one dataset should expect. `se`
is sd / sqrt(reps): how precisely this study pins down the bias. se shrinks with
more replications; sd does not, and it is sd that decides whether a single
published estimate is informative.

---

## The bias decomposition (20 reps, mean +/- se)

Two contaminations push in **opposite** directions. nu = 0.3, 5-minute RV,
i.i.d. noise at xi = 1:

| H true | (i) endpoint spot | (ii) daily average | (iii) + RV error | (iv) + noise |
|---|---|---|---|---|
| 0.10 | 0.097 +/- 0.003 | 0.213 +/- 0.004 | 0.198 +/- 0.004 | 0.183 +/- 0.003 |
| 0.30 | 0.298 +/- 0.006 | 0.364 +/- 0.006 | 0.356 +/- 0.006 | 0.322 +/- 0.009 |
| 0.50 | 0.496 +/- 0.008 | 0.533 +/- 0.007 | 0.528 +/- 0.007 | 0.449 +/- 0.011 |

Daily aggregation biases H-hat **upward at every H tested** -- averaging within
the day smooths the path, and even for Brownian volatility the daily average
has positively correlated increments. Estimation error and noise bias it
**downward**. Reporting only the downward half, as the artifact argument
usually does, misses that the two partly cancel.

**Noise alone is insufficient.** At H_true = 0.5 and nu = 0.3, no noise model
tested -- i.i.d. up to xi = 5, AR(1) with phi = 0.7, bid-ask bounce -- pushed
H-hat below 0.24 in any sampling configuration. Reaching 0.1 requires a weak
signal (low vol-of-vol or coarse sampling), not merely loud noise. This
qualifies the strong form of the artifact claim.

---

## Estimator validation

On exact fBm with no estimation error and no noise, the GJR scaling estimator
is excellent -- recovering H to within 0.01 across H from 0.05 to 0.70:

| H true | 0.05 | 0.10 | 0.20 | 0.30 | 0.50 | 0.70 |
|---|---|---|---|---|---|---|
| GJR H-hat | 0.048 | 0.098 | 0.195 | 0.299 | 0.495 | 0.711 |
| SD | 0.004 | 0.006 | 0.020 | 0.012 | 0.012 | 0.019 |

So the estimator is not the problem. The *input* is. This matters for how the
result is framed: this is not "the GJR estimator is broken", it is "realized
variance is an inadequate proxy for spot variance in a specific, quantifiable
regime".

---

## Run it

```bash
pip install numpy scipy pandas pyarrow
python scripts/run_grid.py --quick            # ~10s sanity check
python scripts/run_grid.py --reps 20          # ~5 min, the numbers quoted above
```

Key modules:

```
roughvol/
  fgn.py        exact fBm/fGn via Davies-Harte (shared with the order-flow project)
  simulate.py   fractional log-vol, efficient price, and three noise models
                (iid, AR(1), bid-ask bounce) -- the noise model IS the argument
  realized.py   RV at any frequency, signature plot, two-scale RV, pre-averaging
  hurst.py      GJR scaling estimator, Cont-Das p-variation, skew translation
```

---

## Why the noise model is the crux

Cont and Das observe that real microstructure noise is far from i.i.d., while
the noise-aware MLE approaches that still find H < 0.5 assume it is close to
i.i.d. So `simulate.py` implements i.i.d., AR(1) and bid-ask-bounce noise, and
the grid sweeps all three. Reporting a bias figure under i.i.d. noise alone
would beg exactly the question at issue.

---

## Why anyone should care

In a rough volatility model the ATM implied-volatility skew decays with
maturity as `tau^(H - 1/2)`. The difference between H = 0.1 and H = 0.3 is the
difference between a skew that explodes at short maturity and one that is
comparatively tame. `hurst.skew_exponent_range` does the translation, so an
interval on H becomes an interval on a quantity a desk actually quotes.

---

## Still to do

- Real data: build RV from Binance 1s klines (BTC, ETH) and Dukascopy EURUSD
  ticks; the Oxford-Man realized library is discontinued, so RV must be
  constructed from raw ticks -- which is a feature, not a cost.
- Locate real assets on the SNR axis and report whether their H-hat is
  informative at all.
- Re-estimate with two-scale and pre-averaged RV (both implemented, neither yet
  swept) to see whether noise-robust RV moves H-hat materially.
- Power curves: days of data needed to separate H = 0.1 from H = 0.3 at 80%.
- Effective SNR including microstructure-noise variance, to repair the k = 1
  cells that fall below the collapse curve.
