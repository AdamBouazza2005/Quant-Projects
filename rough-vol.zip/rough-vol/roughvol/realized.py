"""Realized variance: naive, and two noise-robust alternatives.

Under microstructure noise, naive realized variance is biased upward by
2 n Var(u), and the bias *grows* as you sample more finely -- the opposite of
the intuition that more data is better. The volatility signature plot (mean RV
against sampling interval) makes this visible and is the first diagnostic to
run on any new dataset.

Two standard corrections are implemented:

* `two_scale_rv`   -- Zhang, Mykland and Ait-Sahalia. Combines a subsampled
  average RV with the full-frequency RV to cancel the leading noise bias.
* `preaveraged_rv` -- Jacod, Li, Mykland, Podolskij, Vetter. Averages the
  price over a local window before differencing, which suppresses noise at the
  cost of some smoothing of the signal.

Why this matters for the project: the roughness estimate is computed from a
*series* of daily RVs. If each RV carries estimation error, that error behaves
like an independent shock added to log-volatility, and independent shocks look
maximally rough. So the noise in the estimator propagates directly into the
apparent Hurst exponent. Whether a noise-robust RV changes the answer is the
central experiment.
"""

from __future__ import annotations

import numpy as np


def _daily_blocks(Y: np.ndarray, steps_per_day: int, n_days: int) -> np.ndarray:
    return Y[: n_days * steps_per_day].reshape(n_days, steps_per_day)


def realized_variance(
    Y: np.ndarray, steps_per_day: int, n_days: int, k: int = 1
) -> np.ndarray:
    """Naive RV per day, sampling every `k` fine steps.

    k = 1 uses the finest grid; k = 5 on a 1-minute grid gives 5-minute RV.
    """
    blocks = _daily_blocks(Y, steps_per_day, n_days)
    sub = blocks[:, ::k]
    d = np.diff(sub, axis=1)
    return np.sum(d * d, axis=1)


def signature_plot(
    Y: np.ndarray, steps_per_day: int, n_days: int, ks: list[int] | None = None
) -> tuple[np.ndarray, np.ndarray]:
    """Mean RV against sampling interval k. Returns (ks, mean_rv).

    A flat signature plot means negligible noise. An upward sweep as k -> 1 is
    the noise bias, and its magnitude tells you the noise-to-signal ratio you
    should be feeding into the simulation.
    """
    ks = ks or [1, 2, 3, 5, 10, 15, 30, 60, 120]
    ks = [k for k in ks if k < steps_per_day // 4]
    means = [float(np.mean(realized_variance(Y, steps_per_day, n_days, k))) for k in ks]
    return np.array(ks), np.array(means)


def estimate_noise_variance(Y: np.ndarray, steps_per_day: int, n_days: int) -> float:
    """Estimate Var(u) from the finest-grid RV.

    With i.i.d. noise, E[RV_finest] ~ IV + 2 n Var(u), and for n large the
    noise term dominates, so Var(u) ~ RV_finest / (2n). This is the standard
    Bandi-Russell style estimator. It is biased when noise is autocorrelated,
    which is itself worth reporting.
    """
    blocks = _daily_blocks(Y, steps_per_day, n_days)
    d = np.diff(blocks, axis=1)
    return float(np.mean(np.sum(d * d, axis=1)) / (2.0 * (blocks.shape[1] - 1)))


def noise_to_signal(Y: np.ndarray, steps_per_day: int, n_days: int, k_ref: int = 30) -> float:
    """Ratio of noise sd to the sd of an efficient return over one fine step.

    Uses a coarse RV (less noise-contaminated) as the signal reference.
    """
    var_u = estimate_noise_variance(Y, steps_per_day, n_days)
    rv_coarse = float(np.mean(realized_variance(Y, steps_per_day, n_days, k_ref)))
    step_var = rv_coarse / steps_per_day
    return float(np.sqrt(var_u / step_var)) if step_var > 0 else np.nan


def two_scale_rv(
    Y: np.ndarray, steps_per_day: int, n_days: int, k_slow: int = 30
) -> np.ndarray:
    """Zhang-Mykland-Ait-Sahalia two-scale realized variance, per day.

    Averages the RV computed on all `k_slow` interleaved subgrids, then
    subtracts a scaled full-frequency RV to cancel the leading noise bias.
    """
    blocks = _daily_blocks(Y, steps_per_day, n_days)
    n = blocks.shape[1]

    rv_avg = np.zeros(n_days)
    counts = 0
    for offset in range(k_slow):
        sub = blocks[:, offset::k_slow]
        if sub.shape[1] < 3:
            continue
        d = np.diff(sub, axis=1)
        rv_avg += np.sum(d * d, axis=1)
        counts += 1
    rv_avg /= max(counts, 1)

    d_all = np.diff(blocks, axis=1)
    rv_all = np.sum(d_all * d_all, axis=1)

    n_bar = (n - k_slow + 1) / k_slow
    return rv_avg - (n_bar / n) * rv_all


def preaveraged_rv(
    Y: np.ndarray, steps_per_day: int, n_days: int, window: int | None = None
) -> np.ndarray:
    """Pre-averaged realized variance (Jacod et al.), per day.

    Applies a triangular weight over a window of length `window`, differences
    the pre-averaged series, and applies the standard bias correction.
    """
    blocks = _daily_blocks(Y, steps_per_day, n_days)
    n = blocks.shape[1]
    if window is None:
        window = max(int(np.ceil(np.sqrt(n))), 4)
    if window % 2 == 1:
        window += 1
    h = window // 2

    # Triangular (min(x, 1-x)) pre-averaging weights
    g = np.minimum(np.arange(1, window) / window, 1.0 - np.arange(1, window) / window)
    psi2 = float(np.sum(g**2))
    psi1 = float(np.sum(np.diff(np.concatenate([[0.0], g, [0.0]])) ** 2))

    out = np.empty(n_days)
    for i in range(n_days):
        y = blocks[i]
        # Pre-averaged returns via convolution of first differences
        dy = np.diff(y)
        pa = np.convolve(dy, g[::-1], mode="valid")
        s = float(np.sum(pa**2))
        # Noise bias correction
        var_u = float(np.sum(dy[:-1] * dy[:-1])) / (2.0 * max(len(dy) - 1, 1))
        out[i] = s / psi2 - (psi1 / (2.0 * psi2)) * (len(dy)) * var_u * 2.0 / window
        del h
    return np.maximum(out, 1e-18)


def log_vol_proxy(rv: np.ndarray) -> np.ndarray:
    """Convert a daily realized-variance series to a log-volatility proxy.

    log sigma = 0.5 * log RV. Non-positive RVs (possible for noise-corrected
    estimators) are dropped by the caller, not silently clipped -- a negative
    variance estimate is information about the estimator, not noise to hide.
    """
    return 0.5 * np.log(rv)
