"""Exact simulation of fractional Gaussian noise (fGn).

Davies-Harte circulant embedding. Exact, not approximate: the sample path has
*exactly* the target autocovariance structure, which matters because the whole
point of the validation harness is that ground truth is known.

fGn with Hurst H has autocovariance

    g(k) = 0.5 * (|k-1|^{2H} - 2|k|^{2H} + |k+1|^{2H})

which for large k behaves as g(k) ~ H(2H-1) k^{2H-2}.  So a long-memory series
with autocorrelation decaying as k^{-gamma} corresponds to

    gamma = 2 - 2H,      i.e.   H = 1 - gamma/2

That identity is the bridge between the simulator and the estimators.
"""

from __future__ import annotations

import numpy as np


def fgn_autocovariance(k: np.ndarray, H: float) -> np.ndarray:
    """Autocovariance of unit-variance fGn at integer lags `k`."""
    k = np.abs(np.asarray(k, dtype=float))
    return 0.5 * (
        np.abs(k - 1.0) ** (2 * H) - 2.0 * k ** (2 * H) + (k + 1.0) ** (2 * H)
    )


def fgn(n: int, H: float, rng: np.random.Generator) -> np.ndarray:
    """Draw `n` samples of unit-variance fGn with Hurst exponent `H`.

    Raises ValueError if the circulant embedding is not non-negative definite,
    which can happen for extreme H; for H in (0, 1) with these autocovariances
    it is a theorem that it is, so in practice this never fires.
    """
    if not 0.0 < H < 1.0:
        raise ValueError(f"H must lie in (0, 1), got {H}")
    if n < 2:
        raise ValueError("n must be at least 2")

    g = fgn_autocovariance(np.arange(n + 1), H)
    # Circulant first row of length m = 2n: [g0 .. gn, g_{n-1} .. g1]
    c = np.concatenate([g, g[-2:0:-1]])
    m = c.size

    lam = np.fft.fft(c).real
    if lam.min() < -1e-8 * max(1.0, lam.max()):
        raise ValueError(f"circulant embedding not PSD for H={H}")
    lam = np.clip(lam, 0.0, None)

    z = rng.normal(size=m) + 1j * rng.normal(size=m)
    y = np.fft.fft(np.sqrt(lam / m) * z)
    # Re(y) and Im(y) are two independent draws with the target covariance;
    # we keep the real part. Normalisation verified in tests/test_fgn.py
    # against the closed-form autocovariance.
    return y.real[:n]


def fbm(n: int, H: float, rng: np.random.Generator) -> np.ndarray:
    """Fractional Brownian motion path of length `n` (cumulative sum of fGn)."""
    return np.cumsum(fgn(n, H, rng))


def hurst_from_gamma(gamma: float) -> float:
    """Hurst exponent of the driving fGn giving sign-ACF decay k^{-gamma}."""
    return 1.0 - gamma / 2.0


def gamma_from_hurst(H: float) -> float:
    """Inverse of :func:`hurst_from_gamma`."""
    return 2.0 - 2.0 * H
