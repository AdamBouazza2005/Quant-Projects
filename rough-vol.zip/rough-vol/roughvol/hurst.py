"""Estimating the roughness exponent of a log-volatility series.

Two estimators:

* `gjr_scaling`  -- Gatheral, Jaisson, Rosenbaum. For a self-similar process
  with stationary increments,

        m(q, D) = E |log sigma_{t+D} - log sigma_t|^q  ~  D^{q H}

  so regressing log m(q, D) on log D gives a slope zeta_q, and regressing
  zeta_q on q gives H. Two nested regressions, which is why its standard error
  needs care: the second regression's inputs are estimates.

* `cont_das_pvariation` -- normalised p-th variation. Cont and Das argue the
  scaling estimator applied to realized variance picks up the roughness of the
  *estimation error*, not of spot volatility, and propose looking at the
  behaviour of normalised p-variation directly.

Both assume stationary increments and self-similarity. Neither is valid if the
log-volatility series contains jumps, a deterministic intraday pattern, or a
trend -- all of which are present in real data and must be removed first.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class HurstEstimate:
    H: float
    stderr: float
    method: str
    zeta: dict = field(default_factory=dict)
    detail: dict = field(default_factory=dict)

    def __str__(self) -> str:
        return f"{self.method}: H = {self.H:.4f} +/- {self.stderr:.4f}"


def structure_function(
    log_vol: np.ndarray, q: float, lags: np.ndarray
) -> np.ndarray:
    """m(q, D) for each lag D in `lags`."""
    out = np.empty(lags.size)
    for i, D in enumerate(lags):
        d = log_vol[int(D):] - log_vol[: -int(D)]
        out[i] = float(np.mean(np.abs(d) ** q))
    return out


def gjr_scaling(
    log_vol: np.ndarray,
    qs: tuple[float, ...] = (0.5, 1.0, 1.5, 2.0, 3.0),
    max_lag: int = 50,
    min_lag: int = 1,
    n_boot: int = 0,
    block_len: int | None = None,
    rng: np.random.Generator | None = None,
) -> HurstEstimate:
    """Gatheral-Jaisson-Rosenbaum scaling estimator.

    `max_lag` should stay well below the mean-reversion timescale of volatility
    and well below the sample length; the default of 50 days follows the
    original paper's choice on daily data.

    With `n_boot` > 0 a moving-block bootstrap standard error is computed over
    the whole two-stage procedure, which is the only honest way to get an
    uncertainty here: the naive OLS error from the second regression treats the
    zeta_q as if they were data rather than estimates, and is far too small.
    """
    log_vol = np.asarray(log_vol, dtype=float)
    lags = np.unique(np.round(np.logspace(np.log10(min_lag), np.log10(max_lag), 20)).astype(int))
    lags = lags[(lags >= min_lag) & (lags <= max_lag)]

    H, zeta = _gjr_once(log_vol, qs, lags)

    stderr = np.nan
    method = "gjr_scaling"
    if n_boot > 0:
        rng = rng or np.random.default_rng(0)
        block_len = block_len or max(4 * max_lag, 100)
        boots = []
        for _ in range(n_boot):
            xb = _moving_block_bootstrap(log_vol, block_len, rng)
            try:
                hb, _ = _gjr_once(xb, qs, lags)
                if np.isfinite(hb):
                    boots.append(hb)
            except (ValueError, np.linalg.LinAlgError):
                continue
        if len(boots) > 3:
            stderr = float(np.std(boots, ddof=1))
            method = "gjr_scaling_blockboot"

    return HurstEstimate(
        H=float(H),
        stderr=stderr,
        method=method,
        zeta={float(q): float(z) for q, z in zeta.items()},
        detail={"max_lag": int(max_lag), "n_lags": int(lags.size), "n_obs": int(log_vol.size)},
    )


def _gjr_once(log_vol: np.ndarray, qs, lags) -> tuple[float, dict]:
    zeta = {}
    for q in qs:
        m = structure_function(log_vol, q, lags)
        good = m > 0
        if good.sum() < 3:
            raise ValueError("degenerate structure function")
        slope = np.polyfit(np.log(lags[good]), np.log(m[good]), 1)[0]
        zeta[q] = slope
    qarr = np.array(list(zeta.keys()), dtype=float)
    zarr = np.array([zeta[q] for q in qarr], dtype=float)
    # H is the slope of zeta_q against q, forced through the origin:
    # self-similarity implies zeta_0 = 0, so an intercept is a misspecification.
    H = float(np.sum(qarr * zarr) / np.sum(qarr * qarr))
    return H, zeta


def _moving_block_bootstrap(x: np.ndarray, block_len: int, rng) -> np.ndarray:
    n = x.size
    if block_len >= n:
        return x.copy()
    n_blocks = int(np.ceil(n / block_len))
    starts = rng.integers(0, n - block_len, size=n_blocks)
    return np.concatenate([x[s : s + block_len] for s in starts])[:n]


def cont_das_pvariation(
    log_vol: np.ndarray, p: float = 2.0, max_scale: int = 32
) -> HurstEstimate:
    """Normalised p-th variation estimator (Cont-Das style).

    Computes V_p(K) = sum |x_{t+K} - x_t|^p over a coarse grid of step K,
    normalised per unit time. Summing N/K terms each of size ~K^{pH} and
    dividing by N/K leaves V_p(K) ~ K^{pH}, so the log-log slope is pH.
    """
    x = np.asarray(log_vol, dtype=float)
    scales, vals = [], []
    K = 1
    while K <= max_scale and K < x.size // 8:
        d = np.abs(x[K:] - x[:-K]) ** p
        vals.append(float(np.sum(d[::K]) / (x.size / K)))
        scales.append(K)
        K *= 2
    if len(scales) < 3:
        return HurstEstimate(np.nan, np.nan, "cont_das_pvariation")
    slope = np.polyfit(np.log(scales), np.log(vals), 1)[0]
    H = slope / p
    return HurstEstimate(
        H=float(H),
        stderr=np.nan,
        method="cont_das_pvariation",
        detail={"p": p, "scales": scales, "slope": float(slope)},
    )


def skew_exponent_range(H: float, H_lo: float, H_hi: float) -> dict:
    """Translate a Hurst interval into the ATM skew term-structure exponent.

    In a rough volatility model the at-the-money implied volatility skew decays
    with maturity as tau^(H - 1/2). This is what makes H economically rather
    than merely statistically interesting: it is the difference between a skew
    that explodes at short maturity and one that is nearly flat.
    """
    return {
        "H": H,
        "skew_exponent": H - 0.5,
        "skew_exponent_lo": H_lo - 0.5,
        "skew_exponent_hi": H_hi - 0.5,
    }
