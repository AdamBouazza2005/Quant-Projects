"""Simulating rough volatility and contaminating it the way a real tape does.

The question this project asks is whether a measured Hurst exponent near 0.1
reflects the volatility process or the estimator. To answer that we need to
generate data where the truth is known and the contamination is realistic.

Three ingredients:

1. `fou_log_vol`   -- log-volatility as a (optionally mean-reverting)
   fractional process with prescribed Hurst exponent H and vol-of-vol nu.

2. `simulate_efficient_price` -- the latent semimartingale. Returns over one
   fine step have variance sigma^2 * dt, so the price is built directly at the
   finest sampling grid rather than by nested subsampling.

3. `add_noise` -- microstructure noise. **The noise model is the whole
   argument.** Cont and Das point out that real microstructure noise is far
   from i.i.d., while the noise-aware MLE approaches that still find H < 0.5
   assume it is close to i.i.d. So this module implements i.i.d. noise, AR(1)
   noise, and a bid-ask bounce (MA(1)-like) model, and the experiment grid
   sweeps all three. Reporting a bias figure under i.i.d. noise alone would
   beg exactly the question at issue.

Time is measured in days throughout. `steps_per_day` sets the finest grid.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .fgn import fgn


# --------------------------------------------------------------------------
# Volatility
# --------------------------------------------------------------------------


def fou_log_vol(
    n_steps: int,
    H: float,
    rng: np.random.Generator,
    nu: float = 0.3,
    dt: float = 1.0 / 1440.0,
    mean_rev: float = 0.0,
    log_sigma0: float = np.log(0.02),
) -> np.ndarray:
    """Log-volatility path with Hurst exponent `H`.

    log sigma_t = log sigma_0 + nu * B^H_t   (plus optional OU mean reversion)

    `nu` is the vol-of-vol: the standard deviation of the change in log
    volatility over one day is nu, since B^H has increments scaling as t^H and
    one day is t = 1. Default nu = 0.3 is in the empirically plausible range.

    Mean reversion is optional because it is irrelevant to the short-lag
    scaling the estimator uses: over small lags fOU and fBm are
    indistinguishable, which is exactly why the scaling estimator is applied
    to lags far below the mean-reversion timescale.
    """
    increments = fgn(n_steps, H, rng) * (dt**H) * nu
    path = np.cumsum(increments)
    if mean_rev > 0.0:
        # Discrete OU damping applied to the fractional driver
        out = np.empty(n_steps)
        acc = 0.0
        decay = np.exp(-mean_rev * dt)
        for i in range(n_steps):
            acc = decay * acc + increments[i]
            out[i] = acc
        path = out
    return log_sigma0 + path


# --------------------------------------------------------------------------
# Price
# --------------------------------------------------------------------------


def simulate_efficient_price(
    log_sigma: np.ndarray,
    rng: np.random.Generator,
    dt: float = 1.0 / 1440.0,
    x0: float = 0.0,
) -> np.ndarray:
    """Latent log-price. dX_t = sigma_t dW_t, discretised on the fine grid."""
    sigma = np.exp(log_sigma)
    r = sigma * np.sqrt(dt) * rng.normal(size=sigma.size)
    return x0 + np.cumsum(r)


# --------------------------------------------------------------------------
# Microstructure noise
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class NoiseSpec:
    """How the observed price departs from the efficient one.

    `xi` is the noise-to-signal ratio: sd(noise) divided by the standard
    deviation of an efficient return over one fine step. xi = 1 means the
    noise is as large as the signal at the finest scale, which is realistic
    for tick-by-tick data.
    """

    kind: str = "iid"  # iid | ar1 | bounce | none
    xi: float = 1.0
    phi: float = 0.5  # AR(1) coefficient, used when kind == "ar1"
    tick: float = 0.0  # round observed log-price to this grid if > 0

    def __str__(self) -> str:
        s = f"{self.kind}(xi={self.xi:g}"
        if self.kind == "ar1":
            s += f", phi={self.phi:g}"
        if self.tick > 0:
            s += f", tick={self.tick:g}"
        return s + ")"


def add_noise(
    X: np.ndarray,
    log_sigma: np.ndarray,
    spec: NoiseSpec,
    rng: np.random.Generator,
    dt: float = 1.0 / 1440.0,
) -> np.ndarray:
    """Return the observed log-price Y = X + u."""
    n = X.size
    if spec.kind == "none" or spec.xi <= 0.0:
        Y = X.copy()
    else:
        # Scale noise to the typical one-step efficient return
        step_sd = float(np.mean(np.exp(log_sigma))) * np.sqrt(dt)
        omega = spec.xi * step_sd

        if spec.kind == "iid":
            u = rng.normal(scale=omega, size=n)
        elif spec.kind == "ar1":
            e = rng.normal(scale=omega * np.sqrt(1.0 - spec.phi**2), size=n)
            u = np.empty(n)
            acc = 0.0
            for i in range(n):
                acc = spec.phi * acc + e[i]
                u[i] = acc
        elif spec.kind == "bounce":
            # Bid-ask bounce: sign flips with high probability, giving strong
            # negative first-order autocorrelation in the noise -- the classic
            # MA(1) signature that inflates RV at high frequency.
            q = np.where(rng.random(n) < 0.9, -1.0, 1.0)
            q = np.cumprod(q) * (1.0 if rng.random() < 0.5 else -1.0)
            u = omega * q
        else:
            raise ValueError(f"unknown noise kind {spec.kind!r}")
        Y = X + u

    if spec.tick > 0.0:
        Y = np.round(Y / spec.tick) * spec.tick
    return Y


# --------------------------------------------------------------------------
# One complete synthetic sample
# --------------------------------------------------------------------------


@dataclass
class Sample:
    Y: np.ndarray  # observed log price, fine grid
    X: np.ndarray  # efficient log price, fine grid
    log_sigma: np.ndarray  # true log spot vol, fine grid
    steps_per_day: int
    n_days: int
    H_true: float
    noise: NoiseSpec

    @property
    def dt(self) -> float:
        return 1.0 / self.steps_per_day

    def true_daily_log_vol(self) -> np.ndarray:
        """Daily average of true log sigma -- the target the estimator aims at.

        Averaging log sigma within the day (rather than taking an endpoint)
        matches what integrated variance reflects, and keeps the comparison
        between estimated and true roughness honest.
        """
        ls = self.log_sigma[: self.n_days * self.steps_per_day]
        return ls.reshape(self.n_days, self.steps_per_day).mean(axis=1)


def make_sample(
    H: float,
    n_days: int,
    rng: np.random.Generator,
    steps_per_day: int = 1440,
    nu: float = 0.3,
    noise: NoiseSpec | None = None,
    mean_rev: float = 0.0,
) -> Sample:
    """Generate one full synthetic sample: vol path, price, observed price."""
    noise = noise or NoiseSpec(kind="none", xi=0.0)
    n = n_days * steps_per_day
    dt = 1.0 / steps_per_day
    log_sigma = fou_log_vol(n, H, rng, nu=nu, dt=dt, mean_rev=mean_rev)
    X = simulate_efficient_price(log_sigma, rng, dt=dt)
    Y = add_noise(X, log_sigma, noise, rng, dt=dt)
    return Sample(Y, X, log_sigma, steps_per_day, n_days, H, noise)
