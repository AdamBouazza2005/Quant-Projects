#!/usr/bin/env python3
"""Download Binance Vision 1-minute klines.

Run on your own machine -- needs network access to data.binance.vision.

The roughness estimator needs MANY DAYS, not many trades per day: its lags run
out to 50 days, so a few months of tick data is far too short. Three-plus years
of 1-minute bars is the right input, and it is small (~2 MB per month).

Examples
--------
python scripts/download_klines.py --symbol BTCUSDT --start 2023-01 --end 2026-08
python scripts/download_klines.py --symbol ETHUSDT --start 2023-01 --end 2026-08

Files land in data/klines/<symbol>/ and are checksum-verified. Safe to re-run.
"""

from __future__ import annotations

import argparse
import hashlib
import sys
import urllib.error
import urllib.request
from pathlib import Path

BASE = "https://data.binance.vision/data/spot/monthly/klines"


def months(start: str, end: str) -> list[str]:
    y, m = int(start[:4]), int(start[5:7])
    y1, m1 = int(end[:4]), int(end[5:7])
    out = []
    while (y, m) <= (y1, m1):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


def fetch(url: str, dest: Path) -> bool:
    if dest.exists() and dest.stat().st_size > 0:
        print(f"  have  {dest.name}")
        return True
    try:
        with urllib.request.urlopen(url, timeout=120) as r:
            payload = r.read()
    except urllib.error.HTTPError as e:
        print(f"  MISSING ({e.code})  {dest.name}")
        return False
    except urllib.error.URLError as e:
        print(f"  ERROR {e.reason}  {dest.name}")
        return False
    try:
        with urllib.request.urlopen(url + ".CHECKSUM", timeout=60) as r:
            expected = r.read().decode().split()[0]
        if hashlib.sha256(payload).hexdigest() != expected:
            print(f"  CHECKSUM MISMATCH  {dest.name}")
            return False
    except urllib.error.URLError:
        print(f"  (no checksum for {dest.name})")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(payload)
    print(f"  ok    {dest.name}  ({len(payload) / 1e6:.1f} MB)")
    return True


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--symbol", required=True)
    ap.add_argument("--start", required=True, help="YYYY-MM")
    ap.add_argument("--end", required=True, help="YYYY-MM")
    ap.add_argument("--out", default="data/klines")
    a = ap.parse_args(argv)

    ms = months(a.start, a.end)
    out = Path(a.out) / a.symbol
    print(f"{a.symbol} 1m klines: {len(ms)} month(s) -> {out}")
    ok = sum(
        fetch(f"{BASE}/{a.symbol}/1m/{a.symbol}-1m-{m}.zip", out / f"{a.symbol}-1m-{m}.zip")
        for m in ms
    )
    print(f"done: {ok}/{len(ms)}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
