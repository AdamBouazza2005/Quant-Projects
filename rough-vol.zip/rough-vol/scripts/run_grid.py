#!/usr/bin/env python3
"""Replicated identifiability grid with bootstrap confidence intervals.

Replaces the exploratory 2-replication sweep with something you can quote.

Three experiments:

  collapse       H_true x vol-of-vol nu x sampling k, many replications.
                 Tests whether H-hat collapses onto SNR = 2 nu / sqrt(2/n),
                 fits a threshold curve, and bootstraps everything.
  decomposition  The four-stage bias decomposition (endpoint spot vol, daily
                 average, + RV estimation error, + microstructure noise).
  noise          H_true = 0.5 under each noise model and level.

Two kinds of uncertainty are reported, and they answer different questions:

  sd   dispersion of H-hat across replications. What ONE researcher with ONE
       dataset of this size should expect. Use it for "could this single
       estimate be consistent with H = 0.5?"
  se   standard error of the cell mean (sd / sqrt(reps)). How precisely THIS
       STUDY pins down the bias. Use it for "how sure are you the bias is X?"

Confusing the two is the most common error in simulation studies: se shrinks
with more replications, sd does not, and it is sd that governs whether a
published single-dataset estimate is informative.

Every (cell, replication) gets its own independent seed spawned from one
SeedSequence, so replications are genuinely independent and the whole run is
reproducible from --seed.

Usage
-----
python scripts/run_grid.py --quick             # ~minutes, sanity check
python scripts/run_grid.py --reps 20           # the run to quote
python scripts/run_grid.py --reps 20 --workers 8
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from roughvol.hurst import gjr_scaling  # noqa: E402
from roughvol.realized import log_vol_proxy, realized_variance  # noqa: E402
from roughvol.simulate import NoiseSpec, make_sample  # noqa: E402

RESULTS = Path(__file__).resolve().parents[1] / "results"
RESULTS.mkdir(exist_ok=True)

STEPS_PER_DAY = 1440
KS = (1, 5, 30, 120)  # 1-min, 5-min, 30-min, 2-hour on a 1-minute grid
MAX_LAG = 50


def snr(nu: float, k: int) -> float:
    n_obs = STEPS_PER_DAY // k
    return 2.0 * nu / np.sqrt(2.0 / n_obs)


def _h(rv: np.ndarray) -> float:
    rv = rv[rv > 0]
    return float(gjr_scaling(log_vol_proxy(rv), max_lag=MAX_LAG).H)


# ---------------------------------------------------------------------------
# Workers (top level so they pickle under both fork and spawn)
# ---------------------------------------------------------------------------


def task_collapse(args):
    H, nu, n_days, xi, seed = args
    rng = np.random.default_rng(seed)
    s = make_sample(H, n_days, rng, STEPS_PER_DAY, nu=nu, noise=NoiseSpec("iid", xi))
    # One simulated path serves every sampling frequency. Within a replication
    # the k-cells are correlated; resampling whole replications in the
    # bootstrap preserves that correlation correctly.
    return {k: _h(realized_variance(s.Y, STEPS_PER_DAY, n_days, k)) for k in KS}


def task_decomposition(args):
    H, nu, n_days, xi, k, seed = args
    rng = np.random.default_rng(seed)
    s = make_sample(H, n_days, rng, STEPS_PER_DAY, nu=nu, noise=NoiseSpec("iid", xi))
    ls = s.log_sigma[: n_days * STEPS_PER_DAY].reshape(n_days, STEPS_PER_DAY)
    return {
        "i_endpoint_spot": float(gjr_scaling(ls[:, -1], max_lag=MAX_LAG).H),
        "ii_daily_average": float(gjr_scaling(ls.mean(axis=1), max_lag=MAX_LAG).H),
        "iii_rv_clean": _h(realized_variance(s.X, STEPS_PER_DAY, n_days, k)),
        "iv_rv_noisy": _h(realized_variance(s.Y, STEPS_PER_DAY, n_days, k)),
    }


def task_noise(args):
    kind, xi, phi, nu, n_days, seed = args
    rng = np.random.default_rng(seed)
    spec = NoiseSpec(kind, xi, phi=phi)
    s = make_sample(0.5, n_days, rng, STEPS_PER_DAY, nu=nu, noise=spec)
    return {k: _h(realized_variance(s.Y, STEPS_PER_DAY, n_days, k)) for k in KS}


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------


def describe(v) -> dict:
    v = np.asarray(v, dtype=float)
    v = v[np.isfinite(v)]
    n = v.size
    if n == 0:
        return {"mean": None, "sd": None, "se": None, "n": 0}
    sd = float(np.std(v, ddof=1)) if n > 1 else float("nan")
    return {
        "mean": float(np.mean(v)),
        "sd": sd,
        "se": sd / np.sqrt(n) if n > 1 else float("nan"),
        "p2.5": float(np.percentile(v, 2.5)),
        "p97.5": float(np.percentile(v, 97.5)),
        "n": int(n),
    }


def spearman(x, y) -> float:
    rx = np.argsort(np.argsort(x))
    ry = np.argsort(np.argsort(y))
    return float(np.corrcoef(rx, ry)[0, 1])


def threshold_curve(log_s, h):
    """Fit H-hat(s) = Hmax / (1 + exp(-a (log s - log s0))).

    Returns (Hmax, a, log_s0) or None. s0 is the SNR at which H-hat reaches
    half its plateau.
    """
    from scipy.optimize import curve_fit

    def f(x, hmax, a, ls0):
        return hmax / (1.0 + np.exp(-a * (x - ls0)))

    try:
        p, _ = curve_fit(
            f, log_s, h, p0=[0.45, 2.0, 0.0],
            bounds=([0.05, 0.1, -6.0], [1.0, 20.0, 6.0]), maxfev=20000,
        )
        return tuple(float(x) for x in p)
    except (RuntimeError, ValueError):
        return None


def snr_for_target(params, target: float) -> float:
    """Invert the fitted curve: SNR at which the fitted H-hat equals target."""
    hmax, a, ls0 = params
    if not 0.0 < target < hmax:
        return float("nan")
    return float(np.exp(ls0 - np.log(hmax / target - 1.0) / a))


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------


def run(pool, fn, tasks, label):
    t0 = time.time()
    print(f"  {label}: {len(tasks)} simulations ...", flush=True)
    out = list(pool.map(fn, tasks, chunksize=1))
    print(f"    done in {time.time() - t0:.0f}s", flush=True)
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--reps", type=int, default=20)
    ap.add_argument("--n-days", type=int, default=1000)
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument("--n-boot", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=20260921)
    ap.add_argument("--quick", action="store_true", help="3 reps, 400 days, reduced grid")
    ap.add_argument("--skip", nargs="*", default=[], choices=["collapse", "decomposition", "noise"])
    ap.add_argument("--out", default=None, help="output JSON name (default grid.json)")
    a = ap.parse_args(argv)

    if a.quick:
        a.reps, a.n_days, a.n_boot = 3, 400, 500
    nus = (0.40, 0.20, 0.10, 0.05, 0.02, 0.01)
    H_list = (0.5, 0.3, 0.1) if not a.quick else (0.5,)

    ss = np.random.SeedSequence(a.seed)
    results = {"config": {**vars(a), "nus": nus, "H_list": H_list, "ks": KS,
                          "steps_per_day": STEPS_PER_DAY, "max_lag": MAX_LAG}}
    t_start = time.time()
    out = RESULTS / (a.out or ("grid_quick.json" if a.quick else "grid.json"))

    def save():
        # Written after every section, so a killed run loses at most one section.
        results["runtime_seconds"] = round(time.time() - t_start, 1)
        out.write_text(json.dumps(results, indent=2, default=float))

    print(f"reps={a.reps} n_days={a.n_days} workers={a.workers} seed={a.seed}")

    with ProcessPoolExecutor(max_workers=a.workers) as pool:

        # ---------------- collapse ----------------
        if "collapse" not in a.skip:
            print("\n[collapse]")
            results["collapse"] = {}
            for H in H_list:
                keys = [(nu, r) for nu in nus for r in range(a.reps)]
                seeds = ss.spawn(len(keys))
                tasks = [(H, nu, a.n_days, 1.0, sd) for (nu, _), sd in zip(keys, seeds)]
                raw = run(pool, task_collapse, tasks, f"H_true={H}")

                # est[nu][k] -> array over reps
                est = {nu: {k: [] for k in KS} for nu in nus}
                for (nu, _), res in zip(keys, raw):
                    for k in KS:
                        est[nu][k].append(res[k])

                cells = []
                for nu in nus:
                    for k in KS:
                        d = describe(est[nu][k])
                        cells.append({"nu": nu, "k": k, "n_obs": STEPS_PER_DAY // k,
                                      "snr": snr(nu, k), **d})

                # Point statistics on cell means
                s_arr = np.array([c["snr"] for c in cells])
                m_arr = np.array([c["mean"] for c in cells])
                rho = spearman(s_arr, m_arr)
                params = threshold_curve(np.log(s_arr), m_arr)

                # Bootstrap: resample replications (not cells) and recompute all
                rng = np.random.default_rng(a.seed + int(1000 * H))
                mats = {nu: np.array([est[nu][k] for k in KS]).T for nu in nus}  # reps x len(KS)
                boot_rho, boot_lo, boot_hi, boot_t = [], [], [], {}
                targets = [0.5 * H, H - 0.1] if H >= 0.2 else [0.5 * H]
                for t in targets:
                    boot_t[t] = []
                for _ in range(a.n_boot):
                    idx = rng.integers(0, a.reps, size=a.reps)
                    means = np.array([mats[nu][idx].mean(axis=0) for nu in nus]).ravel()
                    boot_rho.append(spearman(s_arr, means))
                    boot_lo.append(means[s_arr < 1.0].mean())
                    if np.any(s_arr > 4.0):
                        boot_hi.append(means[s_arr > 4.0].mean())
                    p = threshold_curve(np.log(s_arr), means)
                    if p is not None:
                        for t in targets:
                            boot_t[t].append(snr_for_target(p, t))

                def ci(v):
                    v = np.asarray(v, dtype=float)
                    v = v[np.isfinite(v)]
                    if v.size < 10:
                        return [float("nan"), float("nan")]
                    return [float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))]

                lo_cells = [c for c in cells if c["snr"] < 1.0]
                hi_cells = [c for c in cells if c["snr"] > 4.0]
                summary = {
                    "spearman": rho,
                    "spearman_ci95": ci(boot_rho),
                    "mean_H_snr_lt_1": float(np.mean([c["mean"] for c in lo_cells])),
                    "mean_H_snr_lt_1_ci95": ci(boot_lo),
                    "n_cells_snr_lt_1": len(lo_cells),
                    "mean_H_snr_gt_4": float(np.mean([c["mean"] for c in hi_cells])) if hi_cells else None,
                    "mean_H_snr_gt_4_ci95": ci(boot_hi) if hi_cells else None,
                    "n_cells_snr_gt_4": len(hi_cells),
                    # Typical single-dataset sd in the low-SNR regime: governs
                    # whether ONE published estimate is informative.
                    "single_dataset_sd_snr_lt_1": float(np.mean([c["sd"] for c in lo_cells])),
                    "curve": None,
                    "snr_threshold": {},
                }
                if params is not None:
                    summary["curve"] = {"Hmax": params[0], "slope": params[1], "snr50": float(np.exp(params[2]))}
                    for t in targets:
                        summary["snr_threshold"][f"H_hat={t:.2f}"] = {
                            "point": snr_for_target(params, t), "ci95": ci(boot_t[t])}
                results["collapse"][str(H)] = {"cells": cells, "summary": summary}

                print(f"  H_true={H}: Spearman {rho:.3f} {ci(boot_rho)}")
                print(f"    mean H-hat SNR<1  {summary['mean_H_snr_lt_1']:.3f}  CI {summary['mean_H_snr_lt_1_ci95']}"
                      f"  (single-dataset sd {summary['single_dataset_sd_snr_lt_1']:.3f})")
                if hi_cells:
                    print(f"    mean H-hat SNR>4  {summary['mean_H_snr_gt_4']:.3f}  CI {summary['mean_H_snr_gt_4_ci95']}")
                for name, v in summary["snr_threshold"].items():
                    print(f"    SNR needed for {name}: {v['point']:.2f}  CI {v['ci95']}")
                save()

        # ---------------- decomposition ----------------
        if "decomposition" not in a.skip:
            print("\n[decomposition]  nu=0.3, k=5, iid noise xi=1")
            results["decomposition"] = {}
            for H in (0.1, 0.3, 0.5):
                seeds = ss.spawn(a.reps)
                raw = run(pool, task_decomposition,
                          [(H, 0.3, a.n_days, 1.0, 5, sd) for sd in seeds], f"H_true={H}")
                stages = {st: describe([r[st] for r in raw]) for st in raw[0]}
                results["decomposition"][str(H)] = stages
                line = "  ".join(f"{st.split('_', 1)[0]}={v['mean']:.3f}±{v['se']:.3f}" for st, v in stages.items())
                print(f"  H_true={H}:  {line}")
                save()

        # ---------------- noise ----------------
        if "noise" not in a.skip:
            print("\n[noise]  H_true=0.5, nu=0.3")
            specs = [("none", 0.0, 0.0), ("iid", 1.0, 0.0), ("iid", 2.0, 0.0),
                     ("iid", 5.0, 0.0), ("ar1", 2.0, 0.7), ("bounce", 2.0, 0.0)]
            results["noise"] = {}
            for kind, xi, phi in specs:
                seeds = ss.spawn(a.reps)
                raw = run(pool, task_noise, [(kind, xi, phi, 0.3, a.n_days, sd) for sd in seeds],
                          f"{kind} xi={xi}")
                cell = {k: describe([r[k] for r in raw]) for k in KS}
                results["noise"][f"{kind}_xi{xi}_phi{phi}"] = {str(k): v for k, v in cell.items()}
                print("    " + "  ".join(f"k={k}: {v['mean']:.3f}±{v['se']:.3f}" for k, v in cell.items()))
                save()

    save()
    print(f"\nWrote {out}  ({results['runtime_seconds']}s total)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
