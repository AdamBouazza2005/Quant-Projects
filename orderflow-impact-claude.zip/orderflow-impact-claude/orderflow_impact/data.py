"""Loading Binance aggTrades archives into signed order flow.

The archives are zipped CSVs at data.binance.vision. Three details bite:

1. Some files carry a header row and some do not. We sniff per file.
2. Spot timestamps switched from milliseconds to microseconds on 2025-01-01.
   We infer the unit from the magnitude rather than trusting the date.
3. The sign convention. The column is "was the buyer the maker". If the buyer
   was the maker, the *aggressor* was the seller, so the trade sign is -1.
   Getting this backwards flips the response function and silently inverts
   every result, so it is asserted in the tests.

A note on aggTrades versus raw trades: aggTrades merges consecutive fills of a
single aggressive order at one price into one record. That removes exactly the
short-lag positive autocorrelation the project measures, so it biases the
sign ACF at small lags. The analysis script quantifies this by re-running on
raw `trades` for a subsample; do not skip that check.
"""

from __future__ import annotations

import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

AGG_COLUMNS = [
    "agg_trade_id",
    "price",
    "quantity",
    "first_trade_id",
    "last_trade_id",
    "timestamp",
    "is_buyer_maker",
    "is_best_match",
]

RAW_TRADE_COLUMNS = [
    "trade_id",
    "price",
    "quantity",
    "quote_quantity",
    "timestamp",
    "is_buyer_maker",
    "is_best_match",
]


def _infer_time_unit(ts: pd.Series) -> str:
    """Infer 'ms' or 'us' from the magnitude of the epoch timestamps."""
    v = float(pd.to_numeric(ts.iloc[: min(1000, len(ts))], errors="coerce").max())
    # ~1.7e12 for ms in the 2020s; ~1.7e15 for us
    return "us" if v > 1e14 else "ms"


def _read_one_csv(path: Path, columns: list[str]) -> pd.DataFrame:
    """Read one (possibly zipped) Binance CSV, sniffing for a header row."""
    opener = None
    if path.suffix == ".zip":
        with zipfile.ZipFile(path) as zf:
            name = zf.namelist()[0]
            with zf.open(name) as fh:
                first = fh.readline().decode("utf-8", "replace")
        opener = lambda: pd.read_csv(  # noqa: E731
            path, compression="zip", header=None, names=columns,
            skiprows=1 if not first.split(",")[0].strip("\"").isdigit() else 0,
        )
    else:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            first = fh.readline()
        opener = lambda: pd.read_csv(  # noqa: E731
            path, header=None, names=columns,
            skiprows=1 if not first.split(",")[0].strip("\"").isdigit() else 0,
        )
    return opener()


def load_agg_trades(paths: list[str | Path], raw: bool = False) -> pd.DataFrame:
    """Load and concatenate Binance aggTrades (or raw trades) files.

    Returns a frame with columns: timestamp (UTC datetime), price, quantity,
    sign (+1 aggressive buy, -1 aggressive sell), sorted by time.
    """
    columns = RAW_TRADE_COLUMNS if raw else AGG_COLUMNS
    frames = []
    for p in paths:
        p = Path(p)
        if not p.exists():
            raise FileNotFoundError(p)
        frames.append(_read_one_csv(p, columns))
    if not frames:
        raise ValueError("no input files")

    df = pd.concat(frames, ignore_index=True)
    unit = _infer_time_unit(df["timestamp"])
    df["timestamp"] = pd.to_datetime(
        pd.to_numeric(df["timestamp"], errors="coerce"), unit=unit, utc=True
    )
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")

    maker = df["is_buyer_maker"]
    if maker.dtype == object:
        maker = maker.astype(str).str.strip().str.lower().isin({"true", "1"})
    else:
        maker = maker.astype(bool)
    # buyer was the maker  =>  the aggressor was a SELLER  =>  sign = -1
    df["sign"] = np.where(maker, -1, 1).astype(np.int8)

    df = df.dropna(subset=["timestamp", "price"])
    df = df.sort_values("timestamp", kind="mergesort").reset_index(drop=True)
    return df[["timestamp", "price", "quantity", "sign"]]


def to_trade_time(df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    """Extract (signs, prices) arrays indexed by trade number, not clock time.

    Trade time is the right clock for this analysis: the propagator model is
    written in event time, and calendar time introduces spurious structure
    through intraday activity seasonality.
    """
    return (
        df["sign"].to_numpy(dtype=np.int8),
        df["price"].to_numpy(dtype=float),
    )


def estimate_effective_spread(df: pd.DataFrame) -> float:
    """Roll-style effective spread estimate from the trade price series.

    2 * sqrt(-cov(dp_t, dp_{t-1})) when the covariance is negative. Crude, but
    it needs only trade prices, and for the net-of-cost calculation an
    order-of-magnitude figure is enough. Where quote data is available, prefer
    the realised half-spread.
    """
    p = df["price"].to_numpy(dtype=float)
    dp = np.diff(p)
    if dp.size < 3:
        return np.nan
    cov = float(np.cov(dp[1:], dp[:-1])[0, 1])
    return 2.0 * np.sqrt(-cov) if cov < 0 else np.nan


# --------------------------------------------------------------------------
# Parquet path (for pre-converted archives)
# --------------------------------------------------------------------------

#: Column-name synonyms seen across conversion scripts, mapped to our schema.
_SYNONYMS = {
    "timestamp": {"timestamp", "time", "transact_time", "ts", "datetime", "T"},
    "price": {"price", "p", "px"},
    "quantity": {"quantity", "qty", "q", "size", "amount"},
    "is_buyer_maker": {
        "is_buyer_maker", "isbuyermaker", "buyer_maker", "is_buyer_the_maker", "m",
        "buyer_is_maker",
    },
    "sign": {"sign", "side_sign", "trade_sign"},
}


def _resolve_columns(cols) -> dict[str, str]:
    lower = {str(c).lower(): str(c) for c in cols}
    found = {}
    for canon, alts in _SYNONYMS.items():
        for a in alts:
            if a.lower() in lower:
                found[canon] = lower[a.lower()]
                break
    return found


def load_parquet(paths: list[str | Path], columns: list[str] | None = None) -> pd.DataFrame:
    """Load pre-converted Parquet archives into the canonical schema.

    Accepts a range of column namings and either an explicit `sign` column or
    an `is_buyer_maker` flag to derive it from. Reads only the columns needed,
    which matters: an 85M-row month is cheap on four columns and painful on
    all eight.
    """
    frames = []
    for p in paths:
        p = Path(p)
        if not p.exists():
            raise FileNotFoundError(p)
        import pyarrow.parquet as pq

        schema = pq.read_schema(p)
        resolved = _resolve_columns(schema.names)
        missing = {"timestamp", "price"} - set(resolved)
        if missing:
            raise ValueError(
                f"{p.name}: could not find column(s) {sorted(missing)}; "
                f"file has {schema.names}"
            )
        if "sign" not in resolved and "is_buyer_maker" not in resolved:
            raise ValueError(
                f"{p.name}: needs either a 'sign' or an 'is_buyer_maker' column; "
                f"file has {schema.names}"
            )
        want = [resolved[k] for k in resolved if k in
                {"timestamp", "price", "quantity", "is_buyer_maker", "sign"}]
        df = pd.read_parquet(p, columns=want)
        df = df.rename(columns={v: k for k, v in resolved.items()})
        frames.append(df)

    df = pd.concat(frames, ignore_index=True)

    if not pd.api.types.is_datetime64_any_dtype(df["timestamp"]):
        unit = _infer_time_unit(df["timestamp"])
        df["timestamp"] = pd.to_datetime(
            pd.to_numeric(df["timestamp"], errors="coerce"), unit=unit, utc=True
        )
    elif df["timestamp"].dt.tz is None:
        df["timestamp"] = df["timestamp"].dt.tz_localize("UTC")

    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    if "quantity" not in df:
        df["quantity"] = np.nan

    if "sign" in df:
        df["sign"] = np.sign(pd.to_numeric(df["sign"], errors="coerce")).astype(np.int8)
    else:
        maker = df["is_buyer_maker"]
        if maker.dtype == object:
            maker = maker.astype(str).str.strip().str.lower().isin({"true", "1"})
        else:
            maker = maker.astype(bool)
        df["sign"] = np.where(maker, -1, 1).astype(np.int8)

    df = df.dropna(subset=["timestamp", "price"])
    df = df.sort_values("timestamp", kind="mergesort").reset_index(drop=True)
    return df[["timestamp", "price", "quantity", "sign"]]


def iter_days(df: pd.DataFrame, min_trades: int = 50_000):
    """Yield (date, signs, prices) for each UTC day with enough activity.

    Estimating per day and aggregating across days is the right design for
    multi-month samples: it keeps each estimate inside a roughly stationary
    window, and the dispersion across days gives an honest standard error that
    a single pooled estimate cannot.
    """
    # floor("D") keeps a compact datetime dtype; .dt.date would build one
    # Python date object per row.
    for day, g in df.groupby(df["timestamp"].dt.floor("D"), sort=True):
        if len(g) < min_trades:
            continue
        yield (
            day.date(),
            g["sign"].to_numpy(dtype=np.int8),
            g["price"].to_numpy(dtype=float),
        )


def sanity_report(df: pd.DataFrame) -> dict:
    """Checks worth running before trusting anything downstream."""
    s = df["sign"].to_numpy()
    p = df["price"].to_numpy(dtype=float)
    gaps = df["timestamp"].diff().dt.total_seconds().dropna()
    return {
        "n_trades": int(len(df)),
        "start": str(df["timestamp"].iloc[0]),
        "end": str(df["timestamp"].iloc[-1]),
        "buy_fraction": float(np.mean(s > 0)),
        "price_min": float(np.nanmin(p)),
        "price_max": float(np.nanmax(p)),
        "n_zero_or_neg_price": int(np.sum(~(p > 0))),
        "max_gap_seconds": float(gaps.max()) if len(gaps) else np.nan,
        "n_nonmonotonic_timestamps": int(np.sum(gaps < 0)),
        "frac_price_unchanged": float(np.mean(np.diff(p) == 0)),
    }


# --------------------------------------------------------------------------
# Market-order reconstruction
# --------------------------------------------------------------------------


def merge_to_orders(df: pd.DataFrame, price: str = "first") -> tuple[pd.DataFrame, dict]:
    """Collapse aggTrades fragments into one record per taker (market) order.

    Binance aggTrades merges fills of one taker order *at one price*. An order
    that sweeps several price levels still yields several consecutive records
    with an identical timestamp and sign. Treating those fragments as separate
    trades makes the next "trade" sign almost perfectly predictable (and
    untradeable -- the fragments execute atomically), inflates short-lag sign
    autocorrelation, and makes trade prices walk monotonically through the
    sweep. The standard remedy is to merge them.

    `price` chooses the order's reference price:
      first -- first fill, approximately the touch when the order arrived.
               Closest to the model's "price just before trade t". Default.
      last  -- last fill, where the sweep ended.
      vwap  -- volume-weighted average fill.

    Two different orders sharing a sign and the exact same microsecond are
    merged wrongly; at microsecond resolution this is rare, and the returned
    stats let you check how often multi-fill orders occur.
    """
    n = len(df)
    # Compare timestamps as int64, never via .to_numpy(): on a timezone-aware
    # column that returns an object array of Python Timestamps, which at
    # 85M rows costs minutes and several GB of memory.
    ts = df["timestamp"].astype("int64").to_numpy()
    s = df["sign"].to_numpy()
    p = df["price"].to_numpy(dtype=float)
    q = df["quantity"].to_numpy(dtype=float)

    brk = np.empty(n, dtype=bool)
    brk[0] = True
    brk[1:] = (ts[1:] != ts[:-1]) | (s[1:] != s[:-1])
    starts = np.flatnonzero(brk)
    ends = np.r_[starts[1:], n] - 1
    n_fills = ends - starts + 1

    if price == "first":
        px = p[starts]
    elif price == "last":
        px = p[ends]
    elif price == "vwap":
        qq = np.nan_to_num(q, nan=0.0)
        vol = np.add.reduceat(qq, starts)
        with np.errstate(invalid="ignore", divide="ignore"):
            px = np.add.reduceat(p * qq, starts) / vol
        px = np.where(vol > 0, px, p[starts])
    else:
        raise ValueError(f"unknown price choice {price!r}")

    out = pd.DataFrame({
        "timestamp": df["timestamp"].iloc[starts].reset_index(drop=True),
        "price": px,
        "quantity": np.add.reduceat(np.nan_to_num(q, nan=0.0), starts),
        "sign": s[starts],
        "n_fills": n_fills,
    })
    stats = {
        "records_in": int(n),
        "orders_out": int(len(out)),
        "records_per_order": float(n / max(len(out), 1)),
        "frac_orders_multi_fill": float(np.mean(n_fills > 1)),
        "max_fills_in_one_order": int(n_fills.max()),
        "price_choice": price,
    }
    return out, stats


# --------------------------------------------------------------------------
# Bid-ask bounce correction
# --------------------------------------------------------------------------


def estimate_tick(prices: np.ndarray) -> float:
    """Smallest positive price increment actually observed (robust to float noise)."""
    d = np.abs(np.diff(np.asarray(prices, dtype=float)))
    d = d[d > 1e-9]
    if d.size == 0:
        return float("nan")
    return float(np.round(np.percentile(d, 1), 10))


def estimate_spread_from_flips(signs: np.ndarray, prices: np.ndarray) -> dict:
    """Estimate the typical quoted spread from buy-then-sell transitions.

    If a buy prints at the ask and the next order is a sell printing at the
    bid, the trade-price change is -spread plus whatever the mid did in
    between. The mid usually does nothing between consecutive orders, so the
    *mode* of that change, measured in ticks, estimates the spread. Uses the
    mode rather than the mean because the mid-move term is heavy-tailed.
    """
    s = np.asarray(signs)
    p = np.asarray(prices, dtype=float)
    tick = estimate_tick(p)
    flips = (s[:-1] > 0) & (s[1:] < 0)
    d = np.diff(p)[flips]
    if d.size == 0 or not np.isfinite(tick) or tick <= 0:
        return {"spread": float("nan"), "tick": tick, "n_flips": int(d.size)}
    ticks = np.round(d / tick).astype(np.int64)
    vals, counts = np.unique(ticks, return_counts=True)
    mode_ticks = int(vals[np.argmax(counts)])
    spread = max(-mode_ticks, 1) * tick
    return {
        "spread": float(spread),
        "tick": float(tick),
        "spread_ticks": int(max(-mode_ticks, 1)),
        "mode_share": float(counts.max() / counts.sum()),
        "n_flips": int(d.size),
    }


def bounce_corrected_prices(
    signs: np.ndarray, prices: np.ndarray, spread: float
) -> np.ndarray:
    """Mid-price proxy: mid ~ trade price - (spread / 2) * sign.

    A buy's first fill is at the ask = mid + s/2; a sell's at the bid = mid - s/2.
    Subtracting (s/2) * sign removes the bounce. Exact when the spread is
    constant; approximate otherwise, which is why real quote data is the
    proper fix.
    """
    return np.asarray(prices, dtype=float) - 0.5 * spread * np.asarray(signs, dtype=float)
