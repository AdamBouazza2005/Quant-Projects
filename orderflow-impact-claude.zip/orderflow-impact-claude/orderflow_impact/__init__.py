"""Order-flow long memory and the impact propagator."""
__version__ = "0.1.0"
