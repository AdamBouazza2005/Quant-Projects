"""Estimating the long-memory exponent of the trade-sign series.

Three estimators, on purpose:

* `acf_powerlaw_fit`  -- log-log regression on the autocorrelation function.
  The naive one. Easy to explain, easy to bias: the fit range is a free
  parameter and the ACF estimates at long lags are strongly correlated with
  each other, so the OLS standard error is badly understated.

* `gph`               -- Geweke-Porter-Hudak log-periodogram regression.
* `local_whittle`     -- Robinson's local Whittle / Gaussian semiparametric
  estimator. Lower variance than GPH and the usual default in econometrics.

Both frequency-domain estimators target the memory parameter d, related to the
ACF decay exponent by

    C(k) ~ k^{2d - 1}      =>      gamma = 1 - 2d

Reporting the naive estimator alongside two principled ones, and explaining why
they can disagree, is the point. If they agree, the result is robust; if they
do not, that disagreement is the finding.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize_scalar


@dataclass(frozen=True)
class ExponentEstimate:
    """A power-law exponent with an uncertainty and the method that produced it."""

    value: float
    stderr: float
    method: str
    detail: dict

    def __str__(self) -> str:
        return f"{self.method}: {self.value:.4f} +/- {self.stderr:.4f}"


# --------------------------------------------------------------------------
# Autocorrelation
# --------------------------------------------------------------------------


def acf(x: np.ndarray, max_lag: int, demean: bool = True) -> np.ndarray:
    """Sample autocorrelation C(0..max_lag) computed by FFT.

    Returns an array of length max_lag + 1 with C(0) = 1.
    """
    x = np.asarray(x, dtype=float)
    n = x.size
    if max_lag >= n:
        raise ValueError("max_lag must be smaller than the series length")
    y = x - x.mean() if demean else x
    nfft = 1 << int(np.ceil(np.log2(2 * n - 1)))
    f = np.fft.rfft(y, nfft)
    ac = np.fft.irfft(f * np.conjugate(f), nfft)[: max_lag + 1]
    ac /= ac[0]
    return ac


def logspaced_lags(max_lag: int, n_points: int = 60, min_lag: int = 1) -> np.ndarray:
    """Unique log-spaced integer lags, for fitting without over-weighting the tail."""
    raw = np.unique(
        np.round(np.logspace(np.log10(min_lag), np.log10(max_lag), n_points)).astype(int)
    )
    return raw[(raw >= min_lag) & (raw <= max_lag)]


def acf_powerlaw_fit(
    signs: np.ndarray,
    fit_min: int,
    fit_max: int,
    max_lag: int | None = None,
    n_boot: int = 0,
    block_len: int | None = None,
    rng: np.random.Generator | None = None,
) -> ExponentEstimate:
    """Fit C(k) ~ k^{-gamma} by log-log OLS on log-spaced lags.

    If `n_boot` > 0 a moving-block bootstrap standard error is computed, which
    is far more honest than the OLS one. Note that even the block bootstrap
    understates uncertainty under genuine long memory, because no block length
    captures dependence that never dies; treat it as a lower bound.
    """
    signs = np.asarray(signs, dtype=float)
    max_lag = max_lag or fit_max
    c = acf(signs, max_lag)
    lags = logspaced_lags(fit_max, min_lag=fit_min)
    lags = lags[lags <= max_lag]

    gamma, intercept, ols_se = _loglog_slope(lags, c[lags])

    detail = {
        "fit_min": fit_min,
        "fit_max": fit_max,
        "n_lags_used": int(lags.size),
        "intercept": intercept,
        "ols_stderr": ols_se,
    }
    stderr = ols_se
    method = "acf_loglog_ols"

    if n_boot > 0:
        if rng is None:
            rng = np.random.default_rng(0)
        block_len = block_len or max(fit_max * 4, 1000)
        boots = []
        for _ in range(n_boot):
            xb = _moving_block_bootstrap(signs, block_len, rng)
            cb = acf(xb, max_lag)
            vals = cb[lags]
            if np.all(vals > 0):
                g, _, _ = _loglog_slope(lags, vals)
                boots.append(g)
        if len(boots) > 3:
            stderr = float(np.std(boots, ddof=1))
            method = "acf_loglog_blockboot"
            detail["n_boot_ok"] = len(boots)
            detail["block_len"] = block_len

    return ExponentEstimate(float(gamma), float(stderr), method, detail)


def _loglog_slope(lags: np.ndarray, values: np.ndarray) -> tuple[float, float, float]:
    """OLS of log(values) on log(lags); returns (-slope, intercept, stderr)."""
    mask = values > 0
    if mask.sum() < 3:
        return np.nan, np.nan, np.nan
    x = np.log(lags[mask])
    y = np.log(values[mask])
    n = x.size
    X = np.column_stack([np.ones(n), x])
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ coef
    dof = n - 2
    s2 = resid @ resid / dof
    cov = s2 * np.linalg.inv(X.T @ X)
    return -coef[1], coef[0], float(np.sqrt(cov[1, 1]))


def _moving_block_bootstrap(
    x: np.ndarray, block_len: int, rng: np.random.Generator
) -> np.ndarray:
    n = x.size
    n_blocks = int(np.ceil(n / block_len))
    starts = rng.integers(0, n - block_len, size=n_blocks)
    return np.concatenate([x[s : s + block_len] for s in starts])[:n]


# --------------------------------------------------------------------------
# Frequency-domain estimators
# --------------------------------------------------------------------------


def _periodogram(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Fourier frequencies (0, pi) and the periodogram there."""
    x = np.asarray(x, dtype=float)
    x = x - x.mean()
    n = x.size
    f = np.fft.rfft(x)
    per = (np.abs(f) ** 2) / (2.0 * np.pi * n)
    j = np.arange(1, n // 2 + 1)
    lam = 2.0 * np.pi * j / n
    return lam, per[1 : n // 2 + 1]


def gph(x: np.ndarray, m: int | None = None) -> ExponentEstimate:
    """Geweke-Porter-Hudak log-periodogram estimate of d, reported as gamma.

    `m` is the number of low frequencies used; default n^0.5.
    Asymptotic stderr on d is pi / sqrt(24 m).
    """
    lam, per = _periodogram(x)
    n = np.asarray(x).size
    m = m or int(n**0.5)
    m = min(m, lam.size)
    lam_m, per_m = lam[:m], per[:m]
    good = per_m > 0
    reg = np.log(4.0 * np.sin(lam_m / 2.0) ** 2)
    X = np.column_stack([np.ones(good.sum()), reg[good]])
    coef, *_ = np.linalg.lstsq(X, np.log(per_m[good]), rcond=None)
    d = -coef[1]
    d_se = np.pi / np.sqrt(24.0 * m)
    return ExponentEstimate(
        value=1.0 - 2.0 * d,
        stderr=2.0 * d_se,
        method="gph",
        detail={"d": float(d), "d_stderr": float(d_se), "m": int(m)},
    )


def local_whittle(x: np.ndarray, m: int | None = None) -> ExponentEstimate:
    """Robinson's local Whittle estimate of d, reported as gamma.

    Minimises  R(d) = log( m^-1 sum lam_j^{2d} I_j ) - 2d m^-1 sum log lam_j.
    Asymptotic stderr on d is 1 / (2 sqrt(m)).
    """
    lam, per = _periodogram(x)
    n = np.asarray(x).size
    m = m or int(n**0.65)
    m = min(m, lam.size)
    lam_m, per_m = lam[:m], per[:m]
    log_lam_mean = np.mean(np.log(lam_m))

    def objective(d: float) -> float:
        g = np.mean(lam_m ** (2.0 * d) * per_m)
        if not np.isfinite(g) or g <= 0:
            return 1e10
        return np.log(g) - 2.0 * d * log_lam_mean

    res = minimize_scalar(objective, bounds=(-0.49, 0.99), method="bounded")
    d = float(res.x)
    d_se = 1.0 / (2.0 * np.sqrt(m))
    return ExponentEstimate(
        value=1.0 - 2.0 * d,
        stderr=2.0 * d_se,
        method="local_whittle",
        detail={"d": d, "d_stderr": float(d_se), "m": int(m)},
    )
