"""Is the price a martingale, and what would it take to break it?

This is where the project stops being measurement and starts being an answer.
Three pieces:

* `variance_ratio`  -- Lo-MacKinlay test of the martingale null on the observed
  price, in trade time.

* `permanent_impact_counterfactual` -- rebuild a price from the *same measured
  order flow* under a constant (permanent) impact kernel and show what it does
  to the variance ratio and to predictable return. This is the counterfactual
  that makes the result concrete: predictable flow plus permanent impact is a
  money machine, so impact cannot be permanent.

* `sign_predictability` / `net_pnl_per_round_trip` -- how well past signs
  predict the next sign, and what happens to that edge once you pay the spread.

The punchline the project is aiming at: order flow is genuinely predictable,
and that predictability is genuinely not tradeable, and the reason is the decay
of impact.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.signal import fftconvolve


@dataclass(frozen=True)
class VarianceRatio:
    q: int
    ratio: float
    z_stat: float
    p_value: float

    def __str__(self) -> str:
        return f"VR({self.q}) = {self.ratio:.4f}  z = {self.z_stat:+.2f}  p = {self.p_value:.3g}"


def variance_ratio(prices: np.ndarray, q: int, robust: bool = True) -> VarianceRatio:
    """Lo-MacKinlay variance ratio test of the martingale null.

    VR(q) = Var(p_{t+q} - p_t) / (q * Var(p_{t+1} - p_t)).  Equals 1 under a
    martingale.  With `robust`, uses the heteroskedasticity-consistent standard
    error, which is the right choice here: volatility clusters, and the
    homoskedastic version would reject the null for the wrong reason.
    """
    from scipy.stats import norm

    p = np.asarray(prices, dtype=float)
    r = np.diff(p)
    n = r.size
    if q < 2 or q >= n // 2:
        raise ValueError("q must satisfy 2 <= q < n/2")

    mu = r.mean()
    var1 = np.sum((r - mu) ** 2) / (n - 1)
    rq = p[q:] - p[:-q]
    m = (n - q + 1) * (1 - q / n)
    varq = np.sum((rq - q * mu) ** 2) / m
    vr = varq / (q * var1)

    if robust:
        # Heteroskedasticity-consistent variance of VR (Lo & MacKinlay 1988)
        # delta_j = sum_t d_t d_{t-j} / (sum_t d_t)^2, which is already O(1/n):
        # the numerator is O(n) and the denominator O(n^2). An extra factor of
        # n here inflates the standard error by sqrt(n) and destroys all power.
        d = (r - mu) ** 2
        den = np.sum(d) ** 2
        theta = 0.0
        for j in range(1, q):
            num = np.sum(d[j:] * d[:-j])
            delta = num / den if den > 0 else 0.0
            theta += (2.0 * (q - j) / q) ** 2 * delta
        se = np.sqrt(theta) if theta > 0 else np.nan
    else:
        se = np.sqrt(2.0 * (2.0 * q - 1.0) * (q - 1.0) / (3.0 * q * n))

    z = (vr - 1.0) / se if se and np.isfinite(se) and se > 0 else np.nan
    pval = 2.0 * (1.0 - norm.cdf(abs(z))) if np.isfinite(z) else np.nan
    return VarianceRatio(int(q), float(vr), float(z), float(pval))


def permanent_impact_price(signs: np.ndarray, impact_per_trade: float) -> np.ndarray:
    """Counterfactual price under a constant, never-decaying impact kernel."""
    return impact_per_trade * np.cumsum(np.asarray(signs, dtype=float))


def transient_impact_price(
    signs: np.ndarray, G: np.ndarray, kernel_length: int | None = None
) -> np.ndarray:
    """Counterfactual price under a measured transient kernel G(1..L)."""
    signs = np.asarray(signs, dtype=float)
    G = np.asarray(G, dtype=float)
    if kernel_length is not None:
        G = G[:kernel_length]
    k = np.concatenate([[0.0], G])
    return fftconvolve(signs, k, mode="full")[: signs.size]


@dataclass(frozen=True)
class CounterfactualResult:
    impact_per_trade: float
    vr_permanent: float
    vr_transient: float
    vr_observed: float
    predictable_bps_permanent: float
    predictable_bps_transient: float
    fraction_removed: float


def permanent_impact_counterfactual(
    signs: np.ndarray,
    prices: np.ndarray,
    G: np.ndarray,
    acf_vals: np.ndarray,
    q: int = 64,
    price_scale: float | None = None,
) -> CounterfactualResult:
    """Compare observed, transient-impact and permanent-impact worlds.

    `impact_per_trade` is calibrated to G(1) so the permanent world matches the
    real one at the shortest horizon and differs only in what happens next.

    The predictable-return figure is the expected next-step move conditional on
    the sign forecast implied by the measured sign autocorrelation, expressed in
    basis points of `price_scale` (default: mean observed price level).
    """
    signs = np.asarray(signs, dtype=float)
    prices = np.asarray(prices, dtype=float)
    G = np.asarray(G, dtype=float)
    g1 = float(G[0])

    p_perm = permanent_impact_price(signs, g1)
    p_tran = transient_impact_price(signs, G)

    vr_p = variance_ratio(p_perm, q).ratio
    vr_t = variance_ratio(p_tran, q).ratio
    vr_o = variance_ratio(prices, q).ratio

    if price_scale is None:
        price_scale = float(np.mean(np.abs(prices))) or 1.0

    # Expected predictable move over the next q trades, given the sign forecast.
    # Under permanent impact every future trade contributes g1 * C(n);
    # under the measured kernel it contributes the transient response instead.
    n_idx = np.arange(1, q + 1)
    C = np.asarray(acf_vals, dtype=float)
    C = C[: q + 1] if C.size >= q + 1 else np.pad(C, (0, q + 1 - C.size))
    pred_perm = g1 * float(np.sum(C[n_idx]))
    kern = G[:q] if G.size >= q else np.pad(G, (0, q - G.size))
    pred_tran = float(np.sum(kern * C[1 : q + 1]))

    bps_perm = 1e4 * pred_perm / price_scale
    bps_tran = 1e4 * pred_tran / price_scale
    removed = 1.0 - (bps_tran / bps_perm) if bps_perm != 0 else np.nan

    return CounterfactualResult(
        impact_per_trade=g1,
        vr_permanent=vr_p,
        vr_transient=vr_t,
        vr_observed=vr_o,
        predictable_bps_permanent=float(bps_perm),
        predictable_bps_transient=float(bps_tran),
        fraction_removed=float(removed),
    )


@dataclass(frozen=True)
class PredictabilityResult:
    r_squared: float
    n_lags: int
    hit_rate: float
    coefficients: np.ndarray


def sign_predictability(
    signs: np.ndarray, n_lags: int = 50, train_frac: float = 0.5
) -> PredictabilityResult:
    """Out-of-sample R-squared of a linear AR forecast of the next trade sign.

    Deliberately linear and deliberately out-of-sample. The number you want to
    quote is the honest one: fit on the first half, evaluate on the second.
    """
    s = np.asarray(signs, dtype=float)
    n = s.size
    X = np.column_stack([s[n_lags - 1 - j : n - 1 - j] for j in range(n_lags)])
    y = s[n_lags:]
    split = int(len(y) * train_frac)

    Xtr, ytr = X[:split], y[:split]
    Xte, yte = X[split:], y[split:]
    coef, *_ = np.linalg.lstsq(Xtr, ytr, rcond=None)

    pred = Xte @ coef
    ss_res = float(np.sum((yte - pred) ** 2))
    ss_tot = float(np.sum((yte - yte.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else np.nan
    hit = float(np.mean(np.sign(pred) == yte))
    return PredictabilityResult(float(r2), int(n_lags), hit, coef)


def net_pnl_per_round_trip(
    predicted_move: float, spread: float, price_scale: float
) -> float:
    """Expected basis points per round trip after crossing the spread.

    You pay half the spread on entry and half on exit, so a full round trip
    costs one spread. Any edge smaller than that is not an edge.
    """
    return 1e4 * (predicted_move - spread) / price_scale
