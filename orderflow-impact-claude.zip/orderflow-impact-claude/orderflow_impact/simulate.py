"""Synthetic order flow with known ground truth.

Two independent generators, deliberately based on different mechanisms:

1. `gaussian_signs`  -- sign of a long-memory Gaussian process (fGn).  Purely
   statistical; gives a closed form for the sign autocorrelation via the
   arcsine law, so ground truth is exact rather than estimated.

2. `splitting_signs` -- the Lillo-Mike-Farmer order-splitting mechanism: a
   stream of metaorders whose lengths are Pareto distributed, each emitting a
   run of same-signed child trades.  Economically motivated rather than
   statistical, and it produces the same power-law ACF for a different reason.

Having both matters because "order splitting vs herding" is the standard
question about the origin of long memory: the estimator returns the same gamma under a mechanism that is unambiguously
splitting and under one that has no splitting in it at all.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.signal import fftconvolve

from .fgn import fgn, fgn_autocovariance, hurst_from_gamma


# --------------------------------------------------------------------------
# Order flow generators
# --------------------------------------------------------------------------


def gaussian_signs(n: int, gamma: float, rng: np.random.Generator) -> np.ndarray:
    """Trade signs with autocorrelation decaying as k^{-gamma}.

    Built as sign(X_t) for X a unit-variance fGn with H = 1 - gamma/2.
    """
    H = hurst_from_gamma(gamma)
    return np.sign(fgn(n, H, rng)).astype(np.int8)


def gaussian_sign_acf(lags: np.ndarray, gamma: float) -> np.ndarray:
    """Exact sign autocorrelation of :func:`gaussian_signs` (arcsine law).

    For jointly Gaussian (X_0, X_k) with correlation rho,
        E[sign(X_0) sign(X_k)] = (2/pi) arcsin(rho).
    Since arcsin(rho) ~ rho for small rho, the tail exponent is preserved:
    C(k) ~ (2/pi) * H(2H-1) * k^{-gamma}.
    """
    H = hurst_from_gamma(gamma)
    rho = fgn_autocovariance(np.asarray(lags, dtype=float), H)
    rho = np.clip(rho, -1.0, 1.0)
    return (2.0 / np.pi) * np.arcsin(rho)


def splitting_signs(
    n: int,
    alpha: float,
    rng: np.random.Generator,
    min_len: int = 1,
) -> np.ndarray:
    """Lillo-Mike-Farmer order splitting.

    Metaorder lengths L ~ Pareto with tail exponent `alpha` (P(L>x) ~ x^-alpha).
    Each metaorder emits L trades of one random sign.  The resulting sign ACF
    decays with gamma = alpha - 1.
    """
    if alpha <= 1.0:
        raise ValueError("alpha must exceed 1 for finite mean metaorder length")
    out = np.empty(n, dtype=np.int8)
    filled = 0
    while filled < n:
        # Pareto(alpha) with scale min_len, via inverse CDF
        u = rng.random()
        length = int(np.ceil(min_len * u ** (-1.0 / alpha)))
        length = min(length, n - filled)
        out[filled : filled + length] = 1 if rng.random() < 0.5 else -1
        filled += length
    return out


def gamma_from_alpha(alpha: float) -> float:
    """LMF relation between metaorder tail exponent and sign-ACF exponent."""
    return alpha - 1.0


# --------------------------------------------------------------------------
# Price construction
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class Propagator:
    """Transient impact kernel G(l) = G0 / (l0 + l)^beta, defined for l >= 1."""

    beta: float
    G0: float = 1.0
    l0: float = 1.0

    def __call__(self, lags: np.ndarray) -> np.ndarray:
        lags = np.asarray(lags, dtype=float)
        return self.G0 / (self.l0 + lags) ** self.beta

    def kernel(self, length: int) -> np.ndarray:
        """Causal kernel array k with k[0] = 0 and k[j] = G(j) for j >= 1."""
        k = np.zeros(length + 1)
        k[1:] = self(np.arange(1, length + 1))
        return k


def propagator_price(
    signs: np.ndarray,
    prop: Propagator,
    rng: np.random.Generator,
    news_sigma: float = 0.0,
    kernel_length: int | None = None,
) -> np.ndarray:
    """Mid-price path p_t = sum_{t'<t} G(t-t') * eps_{t'} + news.

    `news_sigma` adds an exogenous random-walk component independent of flow.
    """
    signs = np.asarray(signs, dtype=float)
    n = signs.size
    if kernel_length is None:
        kernel_length = n
    k = prop.kernel(kernel_length)
    impact = fftconvolve(signs, k, mode="full")[:n]
    if news_sigma > 0.0:
        impact = impact + np.cumsum(rng.normal(scale=news_sigma, size=n))
    return impact


def theoretical_response(
    lags: np.ndarray,
    acf: np.ndarray,
    prop: Propagator,
    n_tail: int = 20000,
) -> np.ndarray:
    """Exact R(l) implied by a given sign ACF and propagator.

    R(l) = sum_{n=0}^{l-1} G(l-n) C(n)  +  sum_{n>=1} [G(l+n) - G(n)] C(n)

    `acf` must be C(0..L) with C(0) = 1.  The second sum is truncated at
    `n_tail`; it converges because G(l+n) - G(n) -> 0.
    """
    lags = np.asarray(lags, dtype=int)
    max_lag = int(lags.max())
    # Extend the ACF to the tail by power-law extrapolation off its last points
    C = _extend_acf(acf, n_tail + max_lag + 1)

    # Both sums are FFT-computable. Kernel g[j] = G(j) for j >= 1, g[0] = 0.
    N = n_tail + max_lag + 2
    g = np.zeros(N)
    g[1:] = prop(np.arange(1, N))

    # First sum: sum_{n=0}^{l-1} G(l-n) C(n) = (g * C)(l), a causal convolution.
    first = fftconvolve(g, C[:N], mode="full")[: max_lag + 1]

    # Second sum: sum_{n>=1} G(l+n) C(n) - sum_{n>=1} G(n) C(n).
    # The first piece is a cross-correlation of g against C at shift l.
    n_idx = np.arange(1, n_tail + 1)
    const = float(np.sum(g[n_idx] * C[n_idx]))
    cw = np.zeros(N)
    cw[n_idx] = C[n_idx]
    corr = fftconvolve(g, cw[::-1], mode="full")
    # corr index (N-1)+l corresponds to sum_n g[l+n] cw[n]
    shift = N - 1
    second = corr[shift : shift + max_lag + 1] - const

    total = first + second
    total[0] = 0.0
    return total[lags]


def _extend_acf(acf: np.ndarray, n_tail: int) -> np.ndarray:
    """Extend C(0..L) out to index n_tail by fitting a power law to its tail."""
    acf = np.asarray(acf, dtype=float)
    L = acf.size - 1
    if L >= n_tail:
        return acf
    fit_from = max(1, L // 2)
    k = np.arange(fit_from, L + 1)
    c = acf[fit_from:]
    good = c > 0
    out = np.zeros(n_tail + 1)
    out[: L + 1] = acf
    if good.sum() < 2:
        return out
    slope, intercept = np.polyfit(np.log(k[good]), np.log(c[good]), 1)
    ext = np.arange(L + 1, n_tail + 1)
    out[L + 1 :] = np.exp(intercept) * ext**slope
    return out
