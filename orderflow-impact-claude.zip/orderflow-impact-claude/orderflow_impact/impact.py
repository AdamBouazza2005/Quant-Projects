"""Response function and the impact propagator.

The transient-impact model of Bouchaud, Gefen, Potters and Wyart (2004):

    p_t = sum_{t' < t} G(t - t') eps_{t'} + news

Define the sign autocorrelation C(n) = E[eps_t eps_{t+n}], with C(0) = 1, and
the response function R(l) = E[(p_{t+l} - p_t) eps_t].  Substituting the model
and taking expectations gives the exact relation

    R(l) = sum_{n=0}^{l-1} G(l-n) C(n)  +  sum_{n>=1} [G(l+n) - G(n)] C(n)

Collecting terms in G(k) for k = 1..L, both sums contribute and the coefficient
of G(k) collapses to a strikingly simple form:

    R(l) = sum_k M[l, k] G(k),      M[l, k] = C(|l - k|) - C(k)

So recovering G from the two things you can measure directly (R and C) is a
linear inverse problem.  It is ill-conditioned, which is the whole difficulty:
this module solves it with second-difference regularisation and also offers a
parametric fit as an independent route to the same exponent.

The distinction between R and G is central.  R is what you observe; it is contaminated by the fact that
the trade at t predicts *later* trades, which have their own impact.  G is the
causal kernel of one trade alone.  Reading impact off R overstates it.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import least_squares

from .longmemory import _loglog_slope, logspaced_lags


# --------------------------------------------------------------------------
# Response function
# --------------------------------------------------------------------------


def lagged_return_impact(
    signs: np.ndarray, prices: np.ndarray, max_lag: int
) -> np.ndarray:
    """S(j) = E[r_{t+j} eps_t] for j = 0..max_lag-1, where r_t = p_{t+1} - p_t.

    Computed by FFT cross-correlation, with each lag normalised by the number
    of overlapping observations.
    """
    signs = np.asarray(signs, dtype=float)
    prices = np.asarray(prices, dtype=float)
    if prices.size != signs.size:
        raise ValueError("signs and prices must have equal length")
    r = np.diff(prices)
    eps = signs[: r.size]
    n = r.size
    if max_lag >= n:
        raise ValueError("max_lag must be smaller than the series length")

    nfft = 1 << int(np.ceil(np.log2(2 * n - 1)))
    fr = np.fft.rfft(r - r.mean(), nfft)
    fe = np.fft.rfft(eps - eps.mean(), nfft)
    cc = np.fft.irfft(fr * np.conjugate(fe), nfft)[:max_lag]
    counts = n - np.arange(max_lag)
    return cc / counts


def response_function(
    signs: np.ndarray, prices: np.ndarray, max_lag: int
) -> np.ndarray:
    """R(l) = E[(p_{t+l} - p_t) eps_t] for l = 0..max_lag, R(0) = 0.

    Built as the cumulative sum of :func:`lagged_return_impact`, which is both
    faster and numerically better behaved than differencing the price directly
    at every lag.
    """
    s = lagged_return_impact(signs, prices, max_lag)
    out = np.zeros(max_lag + 1)
    out[1:] = np.cumsum(s)
    return out


# --------------------------------------------------------------------------
# Deconvolution
# --------------------------------------------------------------------------


def build_design(acf_vals: np.ndarray, max_lag: int) -> np.ndarray:
    """Matrix M with M[l-1, k-1] = C(|l-k|) - C(k), for l, k = 1..max_lag."""
    needed = 2 * max_lag + 1
    C = np.zeros(needed)
    m = min(acf_vals.size, needed)
    C[:m] = acf_vals[:m]
    idx = np.arange(1, max_lag + 1)
    L, K = np.meshgrid(idx, idx, indexing="ij")
    return C[np.abs(L - K)] - C[K]


def _second_difference_matrix(n: int) -> np.ndarray:
    D = np.zeros((n - 2, n))
    for i in range(n - 2):
        D[i, i] = 1.0
        D[i, i + 1] = -2.0
        D[i, i + 2] = 1.0
    return D


def deconvolve_propagator(
    response: np.ndarray,
    acf_vals: np.ndarray,
    max_lag: int,
    smooth: float = 1e-3,
) -> np.ndarray:
    """Recover G(1..max_lag) from R and C by regularised least squares.

    `smooth` penalises the second difference of G, which suppresses the
    high-frequency ringing that an unregularised solve produces. Report your
    results across a range of `smooth` values -- if the fitted exponent moves
    materially with it, the deconvolution is not identified and you should say
    so rather than pick a flattering value.
    """
    M = build_design(acf_vals, max_lag)
    R = np.asarray(response, dtype=float)[1 : max_lag + 1]
    if R.size != max_lag:
        raise ValueError("response must contain at least max_lag+1 entries")

    scale = np.linalg.norm(M, ord="fro") / np.sqrt(M.size)
    D = _second_difference_matrix(max_lag)
    lam = (smooth * scale) ** 2

    # Regularised normal equations: (M'M + lam D'D) G = M'R.
    # Cholesky on an n x n system rather than least squares on a 2n x n one --
    # same answer, roughly an order of magnitude faster at n in the thousands,
    # which matters because the validation sweeps solve this hundreds of times.
    A = M.T @ M + lam * (D.T @ D)
    b = M.T @ R
    try:
        return cho_solve(cho_factor(A, lower=True), b)
    except np.linalg.LinAlgError:
        return np.linalg.lstsq(A, b, rcond=None)[0]


@dataclass(frozen=True)
class PropagatorFit:
    beta: float
    beta_stderr: float
    G0: float
    l0: float
    method: str
    detail: dict

    def __str__(self) -> str:
        return f"{self.method}: beta = {self.beta:.4f} +/- {self.beta_stderr:.4f}"


#: Minimum ratio of solve grid to fit window. Below this, the deconvolution's
#: boundary artifact leaks into the fitted exponent. Established empirically
#: against known ground truth -- see scripts/run_validation.py, experiment 3.
EDGE_SAFETY_RATIO = 20


def fit_propagator_exponent(
    G: np.ndarray,
    fit_max: int | None = None,
    fit_min: int = 1,
    three_parameter: bool = True,
) -> PropagatorFit:
    """Fit the decay exponent of a deconvolved propagator.

    With `three_parameter` (the default) fits G(l) = G0 / (l0 + l)^beta in log
    space. The offset l0 matters: a pure power-law fit to a kernel with l0 > 0
    is biased *downward*, badly so when short lags are included, because
    (l0+l)^-beta is flatter than l^-beta near the origin.

    `fit_max` should be at most G.size / EDGE_SAFETY_RATIO. The deconvolution
    is accurate pointwise near l = 1 and degrades towards the boundary, where
    the truncated tail of the infinite sum piles up; fitting into that region
    flattens the exponent and can even turn it negative.
    """
    G = np.asarray(G, dtype=float)
    solve_lag = G.size
    fit_max = fit_max or max(solve_lag // EDGE_SAFETY_RATIO, 10)
    fit_max = min(fit_max, solve_lag)
    ratio = solve_lag / max(fit_max, 1)

    lags = np.arange(fit_min, fit_max + 1, dtype=float)
    vals = G[fit_min - 1 : fit_max]
    ok = vals > 0
    if ok.sum() < 4:
        return PropagatorFit(np.nan, np.nan, np.nan, np.nan, "deconvolution_3param", {})

    lags_ok, vals_ok = lags[ok], vals[ok]
    log_vals = np.log(vals_ok)

    detail = {
        "fit_min": int(fit_min),
        "fit_max": int(fit_max),
        "solve_lag": int(solve_lag),
        "edge_ratio": float(ratio),
        "edge_ratio_ok": bool(ratio >= EDGE_SAFETY_RATIO),
        "n_lags": int(ok.sum()),
    }
    if ratio < EDGE_SAFETY_RATIO:
        detail["warning"] = (
            f"fit window is {ratio:.1f}x inside the solve grid; "
            f"below {EDGE_SAFETY_RATIO}x the exponent is biased low"
        )

    if not three_parameter:
        beta, intercept, se = _loglog_slope(lags_ok, vals_ok)
        return PropagatorFit(
            float(beta), float(se), float(np.exp(intercept)), np.nan,
            "deconvolution_loglog", detail,
        )

    def residual(theta):
        log_G0, beta, log_l0 = theta
        return log_G0 - beta * np.log(np.exp(log_l0) + lags_ok) - log_vals

    res = least_squares(
        residual,
        np.array([float(log_vals[0]), 0.3, 0.0]),
        bounds=([-40.0, 0.0, -6.0], [40.0, 2.0, 10.0]),
        xtol=1e-14,
    )
    try:
        dof = max(res.fun.size - 3, 1)
        s2 = float(res.fun @ res.fun) / dof
        cov = s2 * np.linalg.inv(res.jac.T @ res.jac)
        beta_se = float(np.sqrt(max(cov[1, 1], 0.0)))
    except np.linalg.LinAlgError:
        beta_se = np.nan

    return PropagatorFit(
        beta=float(res.x[1]),
        beta_stderr=beta_se,
        G0=float(np.exp(res.x[0])),
        l0=float(np.exp(res.x[2])),
        method="deconvolution_3param",
        detail=detail,
    )


# --------------------------------------------------------------------------
# Parametric route (independent cross-check)
# --------------------------------------------------------------------------


def fit_propagator_parametric(
    response: np.ndarray,
    acf_vals: np.ndarray,
    max_lag: int,
    beta0: float = 0.25,
    G0_init: float | None = None,
) -> PropagatorFit:
    """Fit G(l) = G0 / (l0 + l)^beta directly to the measured R(l).

    Rather than inverting the linear system, this pushes a parametric G through
    the exact R-C-G relation and matches the result to the observed response.
    Much better conditioned than deconvolution; the price is that it assumes
    the functional form. Agreement between the two routes is the evidence that
    the exponent is real and not an artifact of either method.
    """
    R_obs = np.asarray(response, dtype=float)[1 : max_lag + 1]
    M = build_design(acf_vals, max_lag)
    lags = np.arange(1, max_lag + 1, dtype=float)
    if G0_init is None:
        G0_init = max(abs(R_obs[0]), 1e-9)

    # Fit on a log-spaced subset so short lags do not dominate the objective
    sel = logspaced_lags(max_lag, n_points=80, min_lag=1) - 1

    def residual(theta):
        log_G0, beta, log_l0 = theta
        G = np.exp(log_G0) / (np.exp(log_l0) + lags) ** beta
        R_model = M @ G
        return (R_model[sel] - R_obs[sel]) / (np.abs(R_obs[sel]) + 1e-12)

    x0 = np.array([np.log(G0_init), beta0, np.log(1.0)])
    res = least_squares(
        residual, x0, bounds=([-40.0, 0.0, -5.0], [40.0, 2.0, 8.0]), xtol=1e-12
    )

    # Approximate standard errors from the Jacobian at the optimum
    try:
        J = res.jac
        dof = max(res.fun.size - x0.size, 1)
        s2 = float(res.fun @ res.fun) / dof
        cov = s2 * np.linalg.inv(J.T @ J)
        beta_se = float(np.sqrt(max(cov[1, 1], 0.0)))
    except np.linalg.LinAlgError:
        beta_se = np.nan

    return PropagatorFit(
        beta=float(res.x[1]),
        beta_stderr=beta_se,
        G0=float(np.exp(res.x[0])),
        l0=float(np.exp(res.x[2])),
        method="parametric_R_fit",
        detail={"max_lag": int(max_lag), "cost": float(res.cost), "success": bool(res.success)},
    )
