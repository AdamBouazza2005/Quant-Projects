"""Tests. Run with:  python -m pytest tests -q

These are correctness tests, not smoke tests. Each one pins down something
that, if silently wrong, would invalidate every downstream number -- most
importantly the trade sign convention, which flips the response function.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from orderflow_impact.data import load_agg_trades  # noqa: F401  (import guard)
from orderflow_impact.efficiency import variance_ratio
from orderflow_impact.fgn import fgn, fgn_autocovariance, gamma_from_hurst, hurst_from_gamma
from orderflow_impact.impact import (
    build_design,
    deconvolve_propagator,
    response_function,
)
from orderflow_impact.longmemory import acf, local_whittle
from orderflow_impact.simulate import (
    Propagator,
    gaussian_sign_acf,
    gaussian_signs,
    propagator_price,
    splitting_signs,
    theoretical_response,
)


# --------------------------------------------------------------------------
# fGn
# --------------------------------------------------------------------------


def test_fgn_is_unit_variance():
    rng = np.random.default_rng(0)
    x = np.concatenate([fgn(4096, 0.75, rng) for _ in range(40)])
    assert abs(x.var() - 1.0) < 0.05


def test_fgn_autocovariance_matches_theory():
    rng = np.random.default_rng(1)
    H = 0.75
    paths = [fgn(8192, H, rng) for _ in range(60)]
    for k in (1, 4, 16):
        emp = np.mean([np.mean(p[:-k] * p[k:]) for p in paths])
        theory = fgn_autocovariance(np.array([k]), H)[0]
        assert abs(emp - theory) < 0.05 * abs(theory) + 0.01


def test_hurst_gamma_roundtrip():
    for g in (0.2, 0.5, 0.9):
        assert abs(gamma_from_hurst(hurst_from_gamma(g)) - g) < 1e-12


# --------------------------------------------------------------------------
# Sign generation
# --------------------------------------------------------------------------


def test_signs_are_plus_minus_one():
    rng = np.random.default_rng(2)
    s = gaussian_signs(10000, 0.5, rng)
    assert set(np.unique(s)).issubset({-1, 1})


def test_empirical_sign_acf_matches_arcsine_law():
    rng = np.random.default_rng(3)
    n = 2**19
    gamma = 0.5
    s = gaussian_signs(n, gamma, rng)
    c = acf(s, 200)
    for lag in (1, 5, 20, 100):
        theory = gaussian_sign_acf(np.array([lag]), gamma)[0]
        assert abs(c[lag] - theory) < 0.02


def test_splitting_produces_positive_memory():
    rng = np.random.default_rng(4)
    s = splitting_signs(2**18, alpha=1.5, rng=rng)
    c = acf(s, 50)
    assert c[1] > 0.3
    assert c[10] > 0.0
    assert c[1] > c[10]


def test_local_whittle_recovers_gamma():
    rng = np.random.default_rng(5)
    for gamma in (0.3, 0.6):
        s = gaussian_signs(2**19, gamma, rng)
        est = local_whittle(s)
        assert abs(est.value - gamma) < 0.08


# --------------------------------------------------------------------------
# Impact
# --------------------------------------------------------------------------


def test_design_matrix_identity():
    """M[l, k] must equal C(|l-k|) - C(k), with C(0) = 1 on the diagonal."""
    rng = np.random.default_rng(6)
    C = np.concatenate([[1.0], rng.random(40) * 0.3])
    M = build_design(C, 12)
    for l in range(1, 13):
        for k in range(1, 13):
            assert M[l - 1, k - 1] == pytest.approx(C[abs(l - k)] - C[k])


def test_response_matches_theory_on_simulated_data():
    rng = np.random.default_rng(7)
    n, L, gamma = 2**19, 200, 0.5
    s = gaussian_signs(n, gamma, rng)
    prop = Propagator(beta=0.25)
    p = propagator_price(s, prop, rng)
    R = response_function(s, p, L)
    c_th = gaussian_sign_acf(np.arange(0, 60000), gamma)
    R_th = theoretical_response(np.arange(0, L + 1), c_th, prop, n_tail=50000)
    for lag in (1, 5, 25):
        assert abs(R[lag] - R_th[lag]) < 0.03 * abs(R_th[lag])


def test_deconvolution_recovers_kernel_pointwise():
    """With exact inputs, G must come back accurately at short lags."""
    gamma, L = 0.5, 1000
    prop = Propagator(beta=0.25)
    c = gaussian_sign_acf(np.arange(0, 200001), gamma)
    R = theoretical_response(np.arange(0, L + 1), c, prop, n_tail=150000)
    G = deconvolve_propagator(R, c, L, smooth=1e-4)
    for lag in (1, 2, 5, 10):
        assert G[lag - 1] == pytest.approx(prop(np.array([lag]))[0], rel=0.01)


# --------------------------------------------------------------------------
# Efficiency
# --------------------------------------------------------------------------


def test_variance_ratio_does_not_reject_random_walk():
    rng = np.random.default_rng(8)
    p = np.cumsum(rng.normal(size=200_000))
    for q in (8, 32):
        assert abs(variance_ratio(p, q).z_stat) < 3.0


def test_variance_ratio_rejects_trending_series():
    rng = np.random.default_rng(9)
    eps = rng.normal(size=200_000)
    trend = np.cumsum(np.repeat(rng.normal(size=2000), 100))
    p = np.cumsum(eps) + 5.0 * trend
    assert variance_ratio(p, 32).z_stat > 3.0


# --------------------------------------------------------------------------
# Data layer -- the sign convention is the single most dangerous detail
# --------------------------------------------------------------------------


def test_buyer_maker_means_aggressive_sell(tmp_path):
    """is_buyer_maker True  =>  aggressor was the seller  =>  sign = -1."""
    csv = tmp_path / "AAA-aggTrades-2025-01.csv"
    csv.write_text(
        "1,100.0,1.0,1,1,1735689600000,True,True\n"
        "2,100.5,2.0,2,2,1735689601000,False,True\n"
    )
    df = load_agg_trades([csv])
    assert list(df["sign"]) == [-1, 1]
    assert df["price"].tolist() == [100.0, 100.5]


def test_timestamp_unit_inferred(tmp_path):
    """Microsecond timestamps (post-2025 spot) must not be read as milliseconds."""
    csv = tmp_path / "AAA-aggTrades-2025-02.csv"
    csv.write_text(
        "1,100.0,1.0,1,1,1735689600010866,False,True\n"
        "2,100.5,2.0,2,2,1735689601010866,True,True\n"
    )
    df = load_agg_trades([csv])
    assert df["timestamp"].dt.year.iloc[0] == 2025
    assert isinstance(df["timestamp"].iloc[0], pd.Timestamp)
