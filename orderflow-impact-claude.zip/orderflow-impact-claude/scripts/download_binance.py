#!/usr/bin/env python3
"""Download Binance Vision aggTrades (or raw trades) archives.

Run this on your own machine -- it needs network access to data.binance.vision.

Examples
--------
# Three months of BTCUSDT spot aggTrades
python scripts/download_binance.py --symbol BTCUSDT --start 2025-01 --end 2025-03

# Raw trades for one day, for the aggregation-bias check
python scripts/download_binance.py --symbol BTCUSDT --start 2025-01-15 \
    --end 2025-01-15 --data-type trades --interval daily

# A large-tick pair and a perpetual future, for the tick-size comparison
python scripts/download_binance.py --symbol DOGEUSDT --start 2025-01 --end 2025-03
python scripts/download_binance.py --symbol BTCUSDT --market um --start 2025-01 --end 2025-03

Files land in data/<market>/<symbol>/ and are checksum-verified. Re-running
skips anything already present, so it is safe to resume an interrupted pull.
"""

from __future__ import annotations

import argparse
import hashlib
import sys
import urllib.error
import urllib.request
from datetime import date, timedelta
from pathlib import Path

BASE = "https://data.binance.vision/data"
MARKET_PATH = {"spot": "spot", "um": "futures/um", "cm": "futures/cm"}


def month_range(start: str, end: str) -> list[str]:
    y0, m0 = int(start[:4]), int(start[5:7])
    y1, m1 = int(end[:4]), int(end[5:7])
    out = []
    y, m = y0, m0
    while (y, m) <= (y1, m1):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


def day_range(start: str, end: str) -> list[str]:
    d0 = date.fromisoformat(start)
    d1 = date.fromisoformat(end)
    out = []
    d = d0
    while d <= d1:
        out.append(d.isoformat())
        d += timedelta(days=1)
    return out


def build_url(market: str, interval: str, data_type: str, symbol: str, period: str) -> str:
    mp = MARKET_PATH[market]
    return f"{BASE}/{mp}/{interval}/{data_type}/{symbol}/{symbol}-{data_type}-{period}.zip"


def fetch(url: str, dest: Path, verify: bool = True) -> bool:
    if dest.exists() and dest.stat().st_size > 0:
        print(f"  skip (have)  {dest.name}")
        return True
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        with urllib.request.urlopen(url, timeout=120) as r:
            payload = r.read()
    except urllib.error.HTTPError as e:
        print(f"  MISSING ({e.code})  {url.rsplit('/', 1)[-1]}")
        return False
    except urllib.error.URLError as e:
        print(f"  ERROR {e.reason}  {url}")
        return False

    if verify:
        try:
            with urllib.request.urlopen(url + ".CHECKSUM", timeout=60) as r:
                expected = r.read().decode().split()[0]
            actual = hashlib.sha256(payload).hexdigest()
            if actual != expected:
                print(f"  CHECKSUM MISMATCH  {dest.name}")
                return False
        except urllib.error.URLError:
            print(f"  (no checksum available for {dest.name})")

    dest.write_bytes(payload)
    print(f"  ok  {dest.name}  ({len(payload) / 1e6:.1f} MB)")
    return True


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--symbol", required=True)
    ap.add_argument("--start", required=True, help="YYYY-MM (monthly) or YYYY-MM-DD (daily)")
    ap.add_argument("--end", required=True)
    ap.add_argument("--market", default="spot", choices=sorted(MARKET_PATH))
    ap.add_argument("--interval", default="monthly", choices=["monthly", "daily"])
    ap.add_argument("--data-type", default="aggTrades", choices=["aggTrades", "trades"])
    ap.add_argument("--out", default="data")
    ap.add_argument("--no-verify", action="store_true")
    a = ap.parse_args(argv)

    periods = month_range(a.start, a.end) if a.interval == "monthly" else day_range(a.start, a.end)
    out_dir = Path(a.out) / a.market / a.symbol
    print(f"{a.symbol} {a.market} {a.data_type} {a.interval}: {len(periods)} file(s) -> {out_dir}")

    ok = 0
    for period in periods:
        url = build_url(a.market, a.interval, a.data_type, a.symbol, period)
        dest = out_dir / f"{a.symbol}-{a.data_type}-{period}.zip"
        if fetch(url, dest, verify=not a.no_verify):
            ok += 1
    print(f"done: {ok}/{len(periods)} file(s) available in {out_dir}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
