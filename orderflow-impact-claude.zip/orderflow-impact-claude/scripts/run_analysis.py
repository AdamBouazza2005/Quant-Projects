#!/usr/bin/env python3
"""Run the order-flow / impact analysis on real trade data.

Design note: estimates are computed per UTC day and aggregated across days.
A three-month pooled series is not stationary -- activity, tick size relative
to price, and the participant mix all drift -- and pooling would hide that
while producing one over-confident number. Per-day estimation keeps each fit
inside a roughly stationary window, and the dispersion across days is the
standard error you should actually quote.

Usage
-----
python scripts/run_analysis.py --parquet "data/BTCUSDT_2026-0*.parquet" \
    --label BTCUSDT --solve-lag 4000

python scripts/run_analysis.py --zips "data/spot/BTCUSDT/*.zip" --label BTCUSDT

Outputs (into results/):
    <label>_daily.csv      one row per day, every estimate
    <label>_summary.json   cross-day aggregates and the efficiency test
    <label>_curves.npz     mean ACF, response and propagator curves for plotting
"""

from __future__ import annotations

import argparse
import glob
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from orderflow_impact.data import (  # noqa: E402
    estimate_effective_spread,
    bounce_corrected_prices,
    estimate_spread_from_flips,
    iter_days,
    merge_to_orders,
    load_agg_trades,
    load_parquet,
    sanity_report,
)
from orderflow_impact.efficiency import (  # noqa: E402
    permanent_impact_counterfactual,
    sign_predictability,
    variance_ratio,
)
from orderflow_impact.impact import (  # noqa: E402
    EDGE_SAFETY_RATIO,
    deconvolve_propagator,
    fit_propagator_exponent,
    response_function,
)
from orderflow_impact.longmemory import acf, acf_powerlaw_fit, gph, local_whittle  # noqa: E402

RESULTS = Path(__file__).resolve().parents[1] / "results"
RESULTS.mkdir(exist_ok=True)


def analyse_day(signs, prices, solve_lag, vr_qs, n_pred_lags):
    """All per-day estimates. Returns (row_dict, curves_dict)."""
    n = signs.size
    if n < solve_lag * 20:
        return None, None

    c = acf(signs, 2 * solve_lag + 2)
    R = response_function(signs, prices, solve_lag)
    G = deconvolve_propagator(R, c, solve_lag, smooth=1e-4)

    fit_max = max(solve_lag // EDGE_SAFETY_RATIO, 10)
    bfit = fit_propagator_exponent(G, fit_max=fit_max)

    lw = local_whittle(signs)
    # Bandwidth sensitivity: a clean single power law gives the same gamma at
    # every bandwidth. Drift with m means the sign process has structure at
    # short lags that is not the long-memory tail -- report it, do not hide it.
    lw_bw = {e: local_whittle(signs, m=int(n ** e)).value for e in (0.5, 0.6, 0.7, 0.8)}
    g_gph = gph(signs)
    g_acf = acf_powerlaw_fit(signs, fit_min=1, fit_max=min(1000, solve_lag))

    pred = sign_predictability(signs, n_lags=n_pred_lags)
    cf = permanent_impact_counterfactual(
        signs, prices, G, c, q=max(vr_qs), price_scale=float(np.mean(prices))
    )

    row = {
        "n_trades": int(n),
        "price_mean": float(np.mean(prices)),
        "gamma_lw": lw.value,
        "gamma_lw_se": lw.stderr,
        "gamma_lw_m050": lw_bw[0.5],
        "gamma_lw_m060": lw_bw[0.6],
        "gamma_lw_m070": lw_bw[0.7],
        "gamma_lw_m080": lw_bw[0.8],
        "G_nonmonotone_short": bool(np.any(np.diff(G[:20]) > 0)),
        "gamma_gph": g_gph.value,
        "gamma_acf": g_acf.value,
        "beta": bfit.beta,
        "beta_se": bfit.beta_stderr,
        "G0": bfit.G0,
        "l0": bfit.l0,
        "G_at_1": float(G[0]),
        "beta_efficiency_pred": (1.0 - lw.value) / 2.0,
        "sign_r2_oos": pred.r_squared,
        "hit_rate": pred.hit_rate,
        "vr_permanent": cf.vr_permanent,
        "vr_transient": cf.vr_transient,
        "fraction_removed": cf.fraction_removed,
        "pred_bps_permanent": cf.predictable_bps_permanent,
        "pred_bps_transient": cf.predictable_bps_transient,
    }
    for q in vr_qs:
        v = variance_ratio(prices, q)
        row[f"vr_{q}"] = v.ratio
        row[f"vr_{q}_z"] = v.z_stat

    curves = {"acf": c[: solve_lag + 1], "R": R, "G": G}
    return row, curves


def aggregate(series: pd.Series) -> dict:
    """Cross-day mean with a standard error from day-to-day dispersion."""
    v = series.dropna().to_numpy(dtype=float)
    if v.size == 0:
        return {"mean": np.nan, "se": np.nan, "sd": np.nan, "n": 0}
    return {
        "mean": float(np.mean(v)),
        "se": float(np.std(v, ddof=1) / np.sqrt(v.size)) if v.size > 1 else np.nan,
        "sd": float(np.std(v, ddof=1)) if v.size > 1 else np.nan,
        "n": int(v.size),
        "median": float(np.median(v)),
    }


def load_gamma_calibration(path: Path | None = None) -> callable:
    """Build a calibration map from measured local-Whittle gamma to true gamma.

    The local Whittle estimator carries a small upward bias at these sample
    sizes (experiment 1 of the validation harness measures it: roughly +0.03
    at gamma = 0.5). That matters here out of proportion to its size, because
    the efficiency prediction is (1 - gamma)/2, so a +0.03 bias in gamma moves
    the *prediction* by -0.015 -- the same order as beta's standard error. Left
    uncorrected it makes the efficiency test reject when it should not.

    Returns the identity map if no validation file is present, and says so.
    """
    path = path or (RESULTS / "validation.json")
    if not path.exists():
        return lambda g: g
    try:
        tbl = json.loads(path.read_text())["exp1_gamma_recovery"]
        true_g = np.array(sorted(float(k) for k in tbl))
        meas_g = np.array([tbl[f"{g:g}"]["lw"][0] for g in true_g])
        order = np.argsort(meas_g)
        return lambda g: float(np.interp(g, meas_g[order], true_g[order]))
    except (KeyError, ValueError, TypeError):
        return lambda g: g


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--parquet", help="glob for pre-converted parquet files")
    src.add_argument("--zips", help="glob for raw Binance aggTrades zips")
    ap.add_argument("--label", required=True)
    ap.add_argument("--solve-lag", type=int, default=4000)
    ap.add_argument("--vr-q", type=int, nargs="+", default=[8, 32, 128])
    ap.add_argument("--pred-lags", type=int, default=50)
    ap.add_argument("--raw-trades", action="store_true",
                    help="inputs are raw `trades` not `aggTrades` (aggregation-bias check)")
    ap.add_argument("--max-days", type=int, default=None)
    ap.add_argument("--no-merge", action="store_true",
                    help="do NOT merge same-timestamp same-sign aggTrades into market orders")
    ap.add_argument("--order-price", default="first", choices=["first", "last", "vwap"])
    ap.add_argument("--no-bounce-correct", action="store_true",
                    help="use raw trade prices instead of the bounce-corrected mid proxy")
    ap.add_argument("--spread", type=float, default=None,
                    help="quoted spread in price units; default: estimated from buy->sell flips")
    ap.add_argument("--no-calibrate", action="store_true",
                    help="skip the gamma bias correction from validation.json")
    a = ap.parse_args(argv)

    pattern = a.parquet or a.zips
    paths = sorted(glob.glob(pattern))
    if not paths:
        print(f"no files matched {pattern!r}", file=sys.stderr)
        return 1
    print(f"[{a.label}] {len(paths)} file(s)")

    t0 = time.time()
    df = load_parquet(paths) if a.parquet else load_agg_trades(paths, raw=a.raw_trades)
    print(f"  loaded {len(df):,} trades in {time.time() - t0:.1f}s")

    merge_stats = None
    if not a.no_merge:
        df, merge_stats = merge_to_orders(df, price=a.order_price)
        print(f"  merged into market orders: {merge_stats['records_in']:,} records -> "
              f"{merge_stats['orders_out']:,} orders "
              f"({merge_stats['records_per_order']:.2f} records/order, "
              f"{100 * merge_stats['frac_orders_multi_fill']:.1f}% multi-fill, "
              f"max {merge_stats['max_fills_in_one_order']} fills, price={a.order_price})")
    else:
        print("  WARNING: --no-merge: aggTrades fragments treated as separate trades")

    report = sanity_report(df)
    print("  sanity:")
    for k, v in report.items():
        print(f"    {k:28s} {v}")
    if not 0.4 < report["buy_fraction"] < 0.6:
        print("    WARNING: buy fraction far from 0.5 -- check the sign convention")
    if report["n_nonmonotonic_timestamps"] > 0:
        print("    WARNING: non-monotonic timestamps present")

    spread = estimate_effective_spread(df)
    print(f"  Roll effective spread estimate: {spread:.6f} "
          f"({1e4 * spread / report['price_max']:.2f} bps of price)")

    # Bid-ask bounce: a buy prints at the ask and a sell at the bid, so every
    # sign flip moves the trade price by a full spread even when the mid does
    # not move. For BTCUSDT the spread is ~1 tick and impact per order is the
    # same order of magnitude, so uncorrected trade prices can destroy the
    # recovered kernel entirely (validated in simulation: beta becomes
    # undefined; the correction recovers beta = 0.244 vs true 0.25).
    bounce = None
    if not a.no_bounce_correct:
        sg = df["sign"].to_numpy()
        px = df["price"].to_numpy(dtype=float)
        bounce = estimate_spread_from_flips(sg, px)
        if a.spread is not None:
            bounce["spread"] = float(a.spread)
            bounce["source"] = "user"
        else:
            bounce["source"] = "estimated"
        df["price"] = bounce_corrected_prices(sg, px, bounce["spread"])
        print(f"  bounce correction: tick {bounce['tick']}, spread {bounce['spread']} "
              f"({bounce.get('spread_ticks', '?')} tick(s), {bounce['source']}, "
              f"mode share {bounce.get('mode_share', float('nan')):.2f})")
    else:
        print("  WARNING: --no-bounce-correct: raw trade prices include bid-ask bounce")

    rows, dates = [], []
    curve_acc = None
    n_done = 0
    for day, signs, prices in iter_days(df):
        if a.max_days and n_done >= a.max_days:
            break
        row, curves = analyse_day(signs, prices, a.solve_lag, a.vr_q, a.pred_lags)
        if row is None:
            print(f"  {day}: skipped ({signs.size:,} trades, too few for solve-lag)")
            continue
        rows.append(row)
        dates.append(str(day))
        if curve_acc is None:
            curve_acc = {k: v.astype(float).copy() for k, v in curves.items()}
        else:
            for k in curve_acc:
                curve_acc[k] += curves[k]
        n_done += 1
        print(f"  {day}: n={row['n_trades']:>9,}  gamma={row['gamma_lw']:.3f}  "
              f"beta={row['beta']:.3f}  VR(128)={row.get('vr_128', float('nan')):.3f}")

    if not rows:
        print("no usable days", file=sys.stderr)
        return 1

    daily = pd.DataFrame(rows, index=pd.Index(dates, name="date"))
    daily_path = RESULTS / f"{a.label}_daily.csv"
    daily.to_csv(daily_path)

    for k in curve_acc:
        curve_acc[k] /= len(rows)
    np.savez_compressed(RESULTS / f"{a.label}_curves.npz", **curve_acc)

    keys = ["gamma_lw", "gamma_lw_m050", "gamma_lw_m060", "gamma_lw_m070", "gamma_lw_m080",
            "gamma_gph", "gamma_acf", "beta", "beta_efficiency_pred",
            "sign_r2_oos", "hit_rate", "vr_permanent", "vr_transient",
            "fraction_removed", "pred_bps_permanent", "pred_bps_transient"]
    keys += [f"vr_{q}" for q in a.vr_q]
    summary = {k: aggregate(daily[k]) for k in keys if k in daily}

    g = summary["gamma_lw"]["mean"]
    b = summary["beta"]["mean"]
    b_se = summary["beta"]["se"]

    calib = (lambda x: x) if a.no_calibrate else load_gamma_calibration()
    g_cal = calib(g)
    calibrated = abs(g_cal - g) > 1e-9

    def _test(gamma_used):
        pred = (1.0 - gamma_used) / 2.0
        zz = (b - pred) / b_se if b_se and np.isfinite(b_se) and b_se > 0 else np.nan
        return {
            "gamma": gamma_used,
            "beta_predicted": pred,
            "beta_measured": b,
            "beta_se": b_se,
            "z": float(zz) if np.isfinite(zz) else None,
            "consistent_at_5pct": bool(abs(zz) < 1.96) if np.isfinite(zz) else None,
        }

    summary["efficiency_test_raw"] = _test(g)
    summary["efficiency_test"] = _test(g_cal)
    summary["gamma_calibrated"] = calibrated
    summary["gamma_raw"] = g
    summary["gamma_calibrated_value"] = g_cal
    summary["merge"] = merge_stats
    summary["bounce"] = bounce
    summary["frac_days_G_nonmonotone"] = float(daily["G_nonmonotone_short"].mean())
    summary["n_days"] = len(rows)
    summary["spread_estimate"] = float(spread)
    summary["sanity"] = report
    summary["config"] = vars(a)

    (RESULTS / f"{a.label}_summary.json").write_text(json.dumps(summary, indent=2, default=str))

    print("\n" + "=" * 70)
    print(f"{a.label}: cross-day results over {len(rows)} days")
    print("=" * 70)
    for k in keys:
        if k in summary:
            s = summary[k]
            print(f"  {k:24s} {s['mean']:>9.4f}  +/- {s['se']:.4f}  (sd {s['sd']:.4f})")
    print(f"\n  days with non-monotone G at short lags: "
          f"{100 * summary['frac_days_G_nonmonotone']:.0f}%  (should be ~0; G must decay)")
    b_se_ = summary["beta"]["se"]
    if b_se_ and np.isfinite(b_se_) and b_se_ > 0.1:
        print(f"  WARNING: beta standard error {b_se_:.2f} is too wide for the efficiency test "
              f"to have power -- 'consistent' below means 'could not tell', not 'confirmed'")
    print()
    print("  efficiency relation:  beta = (1 - gamma)/2")
    for name, e in (("raw", summary["efficiency_test_raw"]),
                    ("calibrated", summary["efficiency_test"])):
        if name == "calibrated" and not calibrated:
            print("    (no calibration applied -- run scripts/run_validation.py first)")
            break
        zs = f"{e['z']:.2f}" if e["z"] is not None else "n/a"
        print(f"    [{name:10s}] gamma {e['gamma']:.4f} -> predicted beta "
              f"{e['beta_predicted']:.4f} | measured {e['beta_measured']:.4f} "
              f"+/- {e['beta_se']:.4f} | z {zs} | consistent {e['consistent_at_5pct']}")
    print(f"\nWrote {daily_path} and {a.label}_summary.json  ({time.time() - t0:.0f}s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
